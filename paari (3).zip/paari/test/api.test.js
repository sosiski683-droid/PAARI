'use strict';
// Сквозной тест API: node test/api.test.js
const os = require('node:os'), fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'paari-'));
process.env.DATA_DIR = tmp; process.env.DB_FILE = path.join(tmp, 't.db'); process.env.PORT = '0';
const { server } = require('../server.js');

const sleep = ms => new Promise(r => setTimeout(r, ms));
function client(base) {
  let cookie = '';
  return async function call(method, url, body) {
    const r = await fetch(base + url, { method, headers: Object.assign({ cookie }, body !== undefined ? { 'content-type': 'application/json' } : {}), body: body !== undefined ? JSON.stringify(body) : undefined, redirect: 'manual' });
    const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
    const txt = await r.text(); let j = null; try { j = JSON.parse(txt); } catch (_) { j = txt; }
    return { status: r.status, body: j, loc: r.headers.get('location') };
  };
}
const png = 'data:image/png;base64,' + Buffer.concat([Buffer.from('89504e470d0a1a0a', 'hex'), Buffer.alloc(300, 1)]).toString('base64');

server.listen(0, async () => {
  const base = 'http://127.0.0.1:' + server.address().port;
  let ok = 0; const t = (name, cond) => { assert.ok(cond, name); ok++; console.log('  ✓', name); };
  try {
    const a = client(base), b = client(base), anon = client(base);
    let r = await anon('GET', '/api/health'); t('health', r.body.ok && r.body.payments === 'test');
    r = await anon('GET', '/api/feed?seed=1&limit=10'); t('лента без входа: есть посты', r.body.items.length > 5);
    const ids1 = r.body.items.map(i => i.type + i.id).join();
    r = await anon('GET', '/api/feed?seed=2&limit=10'); t('другой seed → другой порядок', r.body.items.map(i => i.type + i.id).join() !== ids1);
    r = await anon('GET', '/api/feed?seed=1&limit=10&int=8:9'); t('интересы влияют: кулинария выше', r.body.items.slice(0, 4).filter(i => i.type === 'post' && i.author.cat === 8).length >= 2);
    r = await anon('GET', '/api/feed?seed=1&mode=following'); t('без входа «подписки» пусто', r.body.items.length === 0);

    // регистрация
    r = await a('POST', '/api/register', { name: 'Анна Мастер', email: 'anna@test.ru', password: 'secret12', did: 'device12345' }); t('регистрация', r.status === 200);
    r = await a('POST', '/api/register', { name: 'X', email: 'anna@test.ru', password: 'secret12' }); t('дубль email → 409', r.status === 409);
    r = await anon('GET', '/api/device?did=device12345'); t('устройство запомнено', r.body.known && r.body.known.email === 'anna@test.ru');
    r = await anon('POST', '/api/login', { email: 'anna@test.ru', password: 'wrong' }); t('неверный пароль → 401', r.status === 401);
    r = await b('POST', '/api/register', { name: 'Борис Клиент', email: 'boris@test.ru', password: 'secret12' }); t('регистрация клиента', r.status === 200);

    // профиль
    r = await a('PUT', '/api/profile', { nick: 'anna.cakes', name: 'Анна Мастер', cat: 8, services: 'торты, капкейки', city: 'Москва', about: 'Пеку торты на заказ уже пять лет.', price_text: 'от 2500', inn: '123456789012', status: 'Самозанятый', confirmAge: true }); t('неверный ИНН отклонён', r.status === 400);
    const inn = (() => { const d = [7, 7, 0, 7, 3, 8, 9, 2, 1, 0]; const n11 = ((7 * d[0] + 2 * d[1] + 4 * d[2] + 10 * d[3] + 3 * d[4] + 5 * d[5] + 9 * d[6] + 4 * d[7] + 6 * d[8] + 8 * d[9]) % 11) % 10; d.push(n11); const n12 = ((3 * d[0] + 7 * d[1] + 2 * d[2] + 4 * d[3] + 10 * d[4] + 3 * d[5] + 5 * d[6] + 9 * d[7] + 4 * d[8] + 6 * d[9] + 8 * d[10]) % 11) % 10; d.push(n12); return d.join(''); })();
    r = await a('PUT', '/api/profile', { nick: 'anna.cakes', name: 'Анна Мастер', cat: 8, services: 'торты, капкейки', city: 'Москва', about: 'Пеку торты на заказ уже пять лет.', price_text: 'от 2500', inn, status: 'Самозанятый', confirmAge: true, avatar: png }); t('профиль создан', r.status === 200 && r.body.profile.nick === 'anna.cakes');
    const annaId = r.body.profile.id;
    t('аватар сохранён как файл', /^\/uploads\/[a-f0-9]+\.png$/.test(r.body.profile.avatar));
    r = await anon('GET', r.body.profile.avatar); t('аватар отдаётся', r.status === 200);

    // пост с фото
    r = await a('POST', '/api/posts', { title: 'Первый торт', text: 'Медовик на 3 кг — готов!', images: [png, png] }); t('пост опубликован', r.status === 200);
    r = await b('POST', '/api/posts', { text: 'хак' }); t('клиент без профиля не может постить', r.status === 403);
    r = await anon('GET', '/api/feed?mode=new&limit=5'); t('новый пост в ленте первым', r.body.items[0].type === 'post' && r.body.items[0].author.id === annaId && r.body.items[0].images.length === 2);
    const postId = r.body.items[0].id;
    r = await b('POST', `/api/posts/${postId}/like`, {}); t('лайк', r.body.liked && r.body.likes === 1);
    r = await b('POST', `/api/pros/${annaId}/follow`, {}); t('подписка', r.body.following);
    r = await b('GET', '/api/feed?mode=following'); t('лента подписок', r.body.items.length === 1 && r.body.items[0].author.id === annaId);

    // заявка → отклик
    r = await b('POST', '/api/requests', { text: 'Нужен торт на день рождения на 15 человек, до 6000 рублей, к субботе', cat: 8, budget: 6000, city: 'Москва' }); t('заявка создана', r.status === 200);
    const reqId = r.body.id;
    r = await a('GET', '/api/requests/inbox'); t('специалист видит заявку', r.body.requests.some(x => x.id === reqId));
    r = await a('POST', `/api/requests/${reqId}/respond`, { text: 'Здравствуйте! Сделаю медовик, звоните +7 999 123-45-67.' }); t('отклик', r.status === 200);
    const convId = r.body.conv_id;
    r = await b('GET', `/api/conversations/${convId}`); t('контакты скрыты в отклике', r.body.messages.some(m => m.text.includes('[контакт скрыт]')) && !r.body.messages.some(m => m.text.includes('999')));
    r = await a('GET', `/api/conversations/${convId}`); t('подсказки консультанта для специалиста', r.body.assist && r.body.assist.topic && r.body.assist.topic.id === 'cake');
    t('оценка стоимости торта', r.body.assist.estimate !== null);

    // заказ и оплата СБП (тест)
    r = await a('POST', `/api/conversations/${convId}/invoice`, { title: 'Медовик 3 кг', amount: 5400 }); t('счёт выставлен', r.status === 200);
    const orderId = r.body.order;
    r = await b('POST', `/api/orders/${orderId}/pay`, {}); t('платёж создан', r.status === 200 && /^\/pay\/[a-f0-9]{16}$/.test(r.body.url));
    const payUrl = r.body.url;
    r = await anon('GET', payUrl); t('страница тестовой оплаты СБП', typeof r.body === 'string' && r.body.includes('СБП'));
    r = await anon('POST', payUrl + '/confirm'); t('оплата подтверждена → редирект', r.status === 303 && r.loc.includes('pay=return'));
    r = await b('GET', `/api/conversations/${convId}`); t('заказ в статусе held', r.body.orders[0].status === 'held' && r.body.paid);
    r = await a('POST', `/api/orders/${orderId}/deliver`, {}); t('результат передан', r.status === 200);
    r = await b('POST', `/api/orders/${orderId}/confirm`, {}); t('получение подтверждено, комиссия 5%', r.body.fee === 270 && r.body.net === 5130);
    r = await b('POST', `/api/orders/${orderId}/review`, { stars: 5, text: 'Очень вкусно!' }); t('отзыв', r.status === 200);
    r = await a('GET', '/api/me'); t('баланс специалиста', r.body.balance === 5130 && r.body.profile.rating === 5);
    r = await a('POST', '/api/subscribe', { months: 6, price: 800 }); t('подписка: платёж на 4560 ₽ (скидка 5%)', r.body.total === 4560);
    r = await anon('POST', r.body.url + '/confirm'); r = await a('GET', '/api/me'); t('подписка активна, уровень 3', r.body.sub && r.body.sub.level === 3);
    r = await a('POST', '/api/subscribe', { months: 3, price: 800 }); t('неверный срок подписки отклонён', r.status === 400);

    // пример-профиль отвечает умно
    r = await anon('GET', '/api/pros?cat=8&q=торт'); const demoCake = r.body.pros.find(p => p.demo && /Кондитер/.test(p.about)); t('пример-кондитер найден', !!demoCake);
    r = await b('POST', '/api/conversations', { pro_id: demoCake.id, text: 'Здравствуйте! Нужен торт на день рождения, 12 человек, бюджет до 5000 рублей, к субботе' }); const dc = r.body.id;
    await sleep(4500);
    r = await b('GET', `/api/conversations/${dc}`); const pm = r.body.messages.filter(m => !m.mine && !m.system);
    t('пример-профиль ответил по существу', pm.length === 1 && /торт/i.test(pm[0].text) && /₽/.test(pm[0].text));
    console.log('     →', pm[0].text.slice(0, 260));
    r = await b('POST', `/api/conversations/${dc}/messages`, { text: 'Согласен, оформляйте' }); await sleep(3500);
    r = await b('GET', `/api/conversations/${dc}`); t('пример-профиль выставил счёт после согласия', r.body.orders.length === 1 && r.body.orders[0].status === 'inv');
    r = await b('POST', `/api/conversations/${dc}/consult`, {}); t('платных консультаций больше нет', r.status === 404);
    r = await anon('GET', '/api/pros'); t('ни у одного профиля нет цены консультации', r.body.pros.every(p => !p.consult_price));

    // спор
    r = await b('GET', `/api/conversations/${dc}`); const cord = r.body.orders[0].id; r = await b('POST', `/api/orders/${cord}/pay`, {}); r = await anon('POST', r.body.url + '/confirm');
    r = await b('POST', `/api/orders/${cord}/dispute`, { reason: 'тест спора' }); t('спор открывается до подтверждения', r.status === 200);
    // избранное и история заказов
    r = await b('POST', `/api/pros/${demoCake.id}/fav`, {}); t('добавлено в избранное', r.body.fav === true);
    r = await b('GET', '/api/favs'); t('избранное содержит профиль', r.body.pros.some(p => p.id === demoCake.id));
    r = await b('POST', `/api/pros/${demoCake.id}/fav`, {}); r = await b('GET', '/api/favs'); t('убрано из избранного', r.body.pros.length === 0);
    r = await b('GET', '/api/orders/mine'); t('история заказов клиента', r.body.orders.length >= 1 && r.body.orders[0].role === 'client' && r.body.orders[0].peer.name);
    r = await anon('GET', '/api/favs'); t('избранное требует входа', r.status === 401);
    r = await anon('POST', '/api/logout', {}); t('выход', r.status === 200);
    console.log(`\nВсе проверки пройдены: ${ok}`);
    process.exitCode = 0;
  } catch (e) { console.error('ПРОВАЛ:', e.message); process.exitCode = 1; }
  finally { server.close(); setTimeout(() => process.exit(process.exitCode), 100); }
});
