'use strict';
/*
 * ПААРИ — сервер. Без внешних зависимостей: только Node.js >= 22.13 (встроенные http, crypto, node:sqlite).
 * Запуск: node server.js   (переменные окружения — см. README.md)
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const brain = require('./brain');
const pay = require('./payments');
const seed = require('./seed');

const PORT = +process.env.PORT || 3000;
const DATA = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC = path.join(__dirname, 'public');
const UPLOADS = path.join(DATA, 'uploads');
const SECURE = /^https:/.test(process.env.PUBLIC_URL || '');
const DEMO_ON = process.env.DEMO_PROFILES !== 'off';
const COMMISSION = 0.05;
fs.mkdirSync(UPLOADS, { recursive: true });

const db = new DatabaseSync(process.env.DB_FILE || path.join(DATA, 'paari.db'));
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT NOT NULL, salt TEXT, hash TEXT, demo INTEGER DEFAULT 0, created INTEGER, interests TEXT DEFAULT '{}');
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created INTEGER);
CREATE TABLE IF NOT EXISTS devices(user_id INTEGER NOT NULL, did TEXT NOT NULL, label TEXT, last INTEGER, PRIMARY KEY(user_id, did));
CREATE TABLE IF NOT EXISTS profiles(user_id INTEGER PRIMARY KEY, nick TEXT UNIQUE, name TEXT, cat INTEGER, services TEXT, city TEXT, education TEXT, experience TEXT, about TEXT, price_text TEXT, price_from INTEGER DEFAULT 0, consult_price INTEGER DEFAULT 0, consult_minutes INTEGER DEFAULT 30, inn TEXT, status TEXT, inn_ok INTEGER DEFAULT 0, avatar TEXT, rating REAL DEFAULT 0, reviews_n INTEGER DEFAULT 0, boost INTEGER DEFAULT 0, boost_until INTEGER DEFAULT 0, demo INTEGER DEFAULT 0, created INTEGER, updated INTEGER);
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, title TEXT, text TEXT, images TEXT DEFAULT '[]', created INTEGER, likes INTEGER DEFAULT 0, deleted INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS posts_user ON posts(user_id, created);
CREATE TABLE IF NOT EXISTS likes(user_id INTEGER, post_id INTEGER, PRIMARY KEY(user_id, post_id));
CREATE TABLE IF NOT EXISTS favs(user_id INTEGER, pro_id INTEGER, created INTEGER, PRIMARY KEY(user_id, pro_id));
CREATE TABLE IF NOT EXISTS follows(user_id INTEGER, pro_id INTEGER, PRIMARY KEY(user_id, pro_id));
CREATE TABLE IF NOT EXISTS requests(id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL, text TEXT, cat INTEGER, budget INTEGER DEFAULT 0, city TEXT, created INTEGER, status TEXT DEFAULT 'open');
CREATE TABLE IF NOT EXISTS convs(id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL, pro_id INTEGER NOT NULL, request_id INTEGER, created INTEGER, last_at INTEGER, UNIQUE(client_id, pro_id));
CREATE TABLE IF NOT EXISTS msgs(id INTEGER PRIMARY KEY, conv_id INTEGER NOT NULL, sender_id INTEGER NOT NULL, kind TEXT DEFAULT 'text', text TEXT, meta TEXT DEFAULT '{}', created INTEGER);
CREATE INDEX IF NOT EXISTS msgs_conv ON msgs(conv_id, id);
CREATE TABLE IF NOT EXISTS reads(conv_id INTEGER, user_id INTEGER, last_id INTEGER DEFAULT 0, PRIMARY KEY(conv_id, user_id));
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, conv_id INTEGER NOT NULL, client_id INTEGER NOT NULL, pro_id INTEGER NOT NULL, kind TEXT DEFAULT 'order', title TEXT, amount INTEGER NOT NULL, status TEXT DEFAULT 'inv', created INTEGER, paid_at INTEGER, done_at INTEGER);
CREATE TABLE IF NOT EXISTS payments(id TEXT PRIMARY KEY, kind TEXT, ref INTEGER, user_id INTEGER, amount INTEGER, status TEXT DEFAULT 'pending', provider_id TEXT, created INTEGER, paid_at INTEGER, meta TEXT DEFAULT '{}');
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY, order_id INTEGER UNIQUE, pro_id INTEGER, client_id INTEGER, author TEXT, stars INTEGER, text TEXT, created INTEGER);
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY, user_id INTEGER, order_id INTEGER, amount INTEGER, fee INTEGER, created INTEGER);
CREATE TABLE IF NOT EXISTS subs(id INTEGER PRIMARY KEY, user_id INTEGER, level INTEGER, months INTEGER, price INTEGER, total INTEGER, until INTEGER, created INTEGER);
CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY, user_id INTEGER, kind TEXT, ref INTEGER, reason TEXT, created INTEGER);
`);

const now = () => Date.now();
const q = sql => db.prepare(sql);
const tx = fn => { db.exec('BEGIN'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { try { db.exec('ROLLBACK'); } catch (_) { /* ignore */ } throw e; } };
const J = (s, d) => { try { return JSON.parse(s); } catch (_) { return d; } };
const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
const str = (v, max) => String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, max);

// ---------- Утилиты HTTP ----------
class HttpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }
const bad = (msg, code) => new HttpError(code || 400, msg);

function send(res, code, obj, headers) {
  const body = typeof obj === 'string' ? obj : JSON.stringify(obj);
  res.writeHead(code, Object.assign({ 'Content-Type': typeof obj === 'string' ? 'text/html; charset=utf-8' : 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers || {}));
  res.end(body);
}
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(bad('Слишком большой запрос', 413)); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}
function cookies(req) { const o = {}; (req.headers.cookie || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); }); return o; }
function setSession(res, token, maxAge) {
  res.setHeader('Set-Cookie', `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${SECURE ? '; Secure' : ''}`);
}

// ---------- Ограничение частоты ----------
const hits = new Map();
function limit(key, max, windowMs) {
  const t = now(); const a = (hits.get(key) || []).filter(x => t - x < windowMs);
  if (a.length >= max) throw bad('Слишком много запросов. Попробуйте чуть позже.', 429);
  a.push(t); hits.set(key, a);
}
setInterval(() => { const t = now(); for (const [k, a] of hits) { const f = a.filter(x => t - x < 3600e3); if (f.length) hits.set(k, f); else hits.delete(k); } }, 600e3).unref();

// ---------- Пароли и сессии ----------
function hashPw(pw, salt) { return crypto.scryptSync(pw, salt, 64).toString('hex'); }
function checkPw(pw, salt, hash) { const a = Buffer.from(hashPw(pw, salt), 'hex'), b = Buffer.from(hash, 'hex'); return a.length === b.length && crypto.timingSafeEqual(a, b); }
function newSession(res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  q('INSERT INTO sessions(token,user_id,created) VALUES(?,?,?)').run(token, userId, now());
  setSession(res, token, 30 * 86400);
}
function userFrom(req) {
  const tk = cookies(req).sid; if (!tk) return null;
  const s = q('SELECT user_id, created FROM sessions WHERE token=?').get(tk);
  if (!s || now() - s.created > 30 * 86400e3) return null;
  return q('SELECT id,email,name,demo,interests FROM users WHERE id=?').get(s.user_id) || null;
}
q('DELETE FROM sessions WHERE created < ?').run(now() - 30 * 86400e3);

function rememberDevice(userId, did, label) {
  did = str(did, 64); if (!/^[a-z0-9]{8,64}$/i.test(did)) return;
  q('INSERT INTO devices(user_id,did,label,last) VALUES(?,?,?,?) ON CONFLICT(user_id,did) DO UPDATE SET last=excluded.last, label=excluded.label').run(userId, did, str(label, 80), now());
}

// ---------- Картинки ----------
function saveImage(dataUrl) {
  const m = /^data:image\/(png|jpeg|jpg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!m) throw bad('Неверный формат изображения (нужен PNG, JPEG или WebP)');
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length < 100 || buf.length > 2.5 * 1024 * 1024) throw bad('Изображение слишком большое (до 2,5 МБ после сжатия)');
  const sig = buf.subarray(0, 4).toString('hex');
  const ok = sig.startsWith('89504e47') || sig.startsWith('ffd8ff') || (buf.subarray(0, 4).toString() === 'RIFF');
  if (!ok) throw bad('Файл не похож на изображение');
  const ext = m[1] === 'png' ? 'png' : m[1] === 'webp' ? 'webp' : 'jpg';
  const name = crypto.randomBytes(12).toString('hex') + '.' + ext;
  fs.writeFileSync(path.join(UPLOADS, name), buf);
  return '/uploads/' + name;
}

// ---------- Контакты скрываются до оплаты ----------
function maskContacts(t) {
  return String(t)
    .replace(/(?:\+?\d[\s\-().]{0,2}){10,}/g, '[контакт скрыт]')
    .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '[контакт скрыт]')
    .replace(/(?:^|\s)@[A-Za-z0-9_]{4,}/g, ' [контакт скрыт]')
    .replace(/(?:https?:\/\/|www\.|t\.me\/|wa\.me\/|vk\.com\/)\S+/gi, '[ссылка скрыта]');
}

// ---------- Профили ----------
const PRO_COLS = 'p.user_id AS id, p.nick, p.name, p.cat, p.services, p.city, p.education, p.experience, p.about, p.price_text, p.price_from, p.consult_price, p.consult_minutes, p.status, p.inn_ok, p.avatar, p.rating, p.reviews_n, p.boost, p.boost_until, p.demo, p.created';
function pubPro(r) {
  if (!r) return null;
  return { id: r.id, nick: r.nick, name: r.name, cat: r.cat, services: r.services, city: r.city, education: r.education, experience: r.experience, about: r.about, price_text: r.price_text, price_from: r.price_from, consult_price: r.consult_price, consult_minutes: r.consult_minutes, status: r.status, verified: !!r.inn_ok, avatar: r.avatar, rating: r.rating, reviews_n: r.reviews_n, boost: r.boost_until > now() ? r.boost : 0, demo: !!r.demo, created: r.created };
}
const demoFilter = () => (DEMO_ON ? '' : ' AND p.demo=0');
function getPro(id) { return pubPro(q(`SELECT ${PRO_COLS} FROM profiles p WHERE p.user_id=?${demoFilter()}`).get(id)); }
function proRow(id) { return q('SELECT * FROM profiles WHERE user_id=?').get(id); }

function validINN(v) {
  if (!/^\d{12}$/.test(v)) return false;
  const d = v.split('').map(Number);
  const n11 = ((7 * d[0] + 2 * d[1] + 4 * d[2] + 10 * d[3] + 3 * d[4] + 5 * d[5] + 9 * d[6] + 4 * d[7] + 6 * d[8] + 8 * d[9]) % 11) % 10;
  const n12 = ((3 * d[0] + 7 * d[1] + 2 * d[2] + 4 * d[3] + 10 * d[4] + 3 * d[5] + 5 * d[6] + 9 * d[7] + 4 * d[8] + 6 * d[9] + 8 * d[10]) % 11) % 10;
  return n11 === d[10] && n12 === d[11];
}
async function checkNpd(userId, inn) { // best-effort: публичный сервис ФНС проверки статуса НПД
  try {
    const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 6000);
    const r = await fetch('https://statusnpd.nalog.ru/api/v1/tracker/taxpayer_status', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ inn, requestDate: new Date().toISOString().slice(0, 10) }), signal: ctl.signal });
    clearTimeout(tm);
    const j = await r.json();
    if (j && j.status === true) q('UPDATE profiles SET inn_ok=1 WHERE user_id=?').run(userId);
  } catch (_) { /* нет сети или сервис недоступен — профиль останется «на проверке» */ }
}

// ---------- Подсчёты ----------
function stats(userId) {
  return {
    posts: q('SELECT COUNT(*) c FROM posts WHERE user_id=? AND deleted=0').get(userId).c,
    followers: q('SELECT COUNT(*) c FROM follows WHERE pro_id=?').get(userId).c,
    done: q("SELECT COUNT(*) c FROM orders WHERE pro_id=? AND status='done'").get(userId).c,
  };
}
function recalcRating(proId) {
  const r = q('SELECT COUNT(*) n, AVG(stars) a FROM reviews WHERE pro_id=?').get(proId);
  const real = q('SELECT rating, reviews_n, demo FROM profiles WHERE user_id=?').get(proId);
  if (!real) return;
  if (real.demo) { return; } // у примеров рейтинг фиксирован
  q('UPDATE profiles SET rating=?, reviews_n=? WHERE user_id=?').run(r.n ? Math.round(r.a * 10) / 10 : 0, r.n, proId);
}

// ---------- Лента ----------
function mulberry(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function hstr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

function parseInterests(s) {
  const o = {};
  String(s || '').split(',').forEach(p => { const [c, v] = p.split(':'); const ci = +c, vv = parseFloat(v); if (ci >= 0 && ci < brain.CATS.length && isFinite(vv)) o[ci] = clamp(vv, 0, 100); });
  return o;
}
function mergeInterests(a, b) { const o = Object.assign({}, a); for (const k in b) o[k] = Math.max(o[k] || 0, b[k]); return o; }

const REASONS = { interest: c => 'Вам интересно: ' + brain.CATS[c], city: () => 'Рядом с вами', fresh: () => 'Свежая публикация', pop: () => 'Нравится другим', boost: () => 'Продвигается', quality: () => 'Высокий рейтинг', follow: () => 'Вы подписаны', explore: () => 'Новое для вас' };

function feed(user, p) {
  const t = now();
  const interests = mergeInterests(user ? J(user.interests, {}) : {}, parseInterests(p.int));
  const maxInt = Math.max(1, ...Object.values(interests));
  const seen = new Set(String(p.seen || '').split(',').map(Number).filter(Boolean));
  const rng0 = hstr(String(p.seed || '1'));
  const city = str(p.city, 60).toLowerCase();
  const follows = new Set(user ? q('SELECT pro_id FROM follows WHERE user_id=?').all(user.id).map(r => r.pro_id) : []);
  const favs = new Set(user ? q('SELECT pro_id FROM favs WHERE user_id=?').all(user.id).map(r => r.pro_id) : []);
  const mode = ['foryou', 'new', 'following'].includes(p.mode) ? p.mode : 'foryou';
  const catF = p.cat !== undefined && p.cat !== '' ? +p.cat : -1;
  const qs = str(p.q, 80).toLowerCase();

  let rows = q(`SELECT po.id AS pid, po.user_id, po.title, po.text, po.images, po.created, po.likes, ${PRO_COLS}
    FROM posts po JOIN profiles p ON p.user_id=po.user_id WHERE po.deleted=0 ${demoFilter()} ORDER BY po.created DESC LIMIT 600`).all();
  if (catF >= 0) rows = rows.filter(r => r.cat === catF);
  if (qs) rows = rows.filter(r => (r.title + ' ' + r.text + ' ' + r.name + ' ' + r.services + ' ' + brain.CATS[r.cat] + ' ' + r.city).toLowerCase().includes(qs));
  if (mode === 'following') rows = rows.filter(r => follows.has(r.user_id));
  const liked = new Set(user ? q('SELECT post_id FROM likes WHERE user_id=?').all(user.id).map(r => r.post_id) : []);

  const items = rows.map(r => {
    const ageH = (t - r.created) / 3600e3;
    const terms = {
      interest: 1.4 * ((interests[r.cat] || 0) / maxInt) * (Object.keys(interests).length ? 1 : 0),
      city: city && (r.city || '').toLowerCase() === city ? 0.6 : (r.city === 'Удалённо' ? 0.15 : 0),
      quality: 0.5 * ((r.rating || 4) / 5) + (r.inn_ok ? 0.2 : 0),
      fresh: 0.8 * Math.exp(-ageH / 96),
      pop: 0.3 * Math.min(1, Math.log1p(r.likes) / 4),
      boost: r.boost_until > t ? 0.45 * (r.boost / 3) : 0,
      follow: follows.has(r.user_id) ? 0.9 : 0,
    };
    const real = r.demo ? 0 : 0.35;
    const rng = mulberry(rng0 ^ r.pid * 2654435761)();
    const noise = 0.4 * rng;
    let score = real + noise; let top = 'explore', topv = 0.0001;
    for (const k in terms) { score += terms[k]; if (terms[k] > topv) { topv = terms[k]; top = k; } }
    if (seen.has(r.pid)) score -= 0.9;
    return { score, top, r, cat: r.cat };
  });

  let order;
  if (mode === 'new' || mode === 'following') order = items.sort((a, b) => b.r.created - a.r.created);
  else {
    // жадный подбор с разнообразием: не более одного автора подряд и разные направления
    const pool = items.sort((a, b) => b.score - a.score);
    order = []; const rest = pool.slice();
    while (rest.length && order.length < 160) {
      const lastA = order.slice(-3).map(x => x.r.user_id), lastC = order.slice(-2).map(x => x.cat);
      let bi = 0, bv = -1e9;
      for (let i = 0; i < Math.min(14, rest.length); i++) {
        const c = rest[i]; const v = c.score - (lastA.includes(c.r.user_id) ? 0.7 : 0) - (lastC.includes(c.cat) ? 0.18 : 0);
        if (v > bv) { bv = v; bi = i; }
      }
      order.push(rest.splice(bi, 1)[0]);
    }
  }

  const offset = clamp(+p.offset || 0, 0, 1000), limitN = clamp(+p.limit || 12, 1, 30);
  const slice = order.slice(offset, offset + limitN);
  const out = [];
  // рекомендации специалистов: раз в 5 карточек
  let suggestions = [];
  if (mode === 'foryou') {
    const authors = new Set(slice.map(s => s.r.user_id));
    let pros = q(`SELECT ${PRO_COLS} FROM profiles p WHERE 1=1 ${demoFilter()}`).all().filter(r => !authors.has(r.id) && !follows.has(r.id) && (!user || r.id !== user.id));
    if (catF >= 0) pros = pros.filter(r => r.cat === catF);
    pros = pros.map(r => {
      const rng = mulberry(rng0 ^ (r.id * 40503 + offset))();
      const sc = 1.2 * ((interests[r.cat] || 0) / maxInt) + (city && (r.city || '').toLowerCase() === city ? 0.5 : 0) + 0.4 * (r.rating || 4) / 5 + (r.demo ? 0 : 0.3) + (r.boost_until > t ? 0.4 * r.boost / 3 : 0) + 0.5 * rng;
      return { sc, r };
    }).sort((a, b) => b.sc - a.sc);
    suggestions = pros.slice(0, Math.ceil(slice.length / 5)).map(x => x.r);
  }
  let si = 0;
  slice.forEach((s, i) => {
    const r = s.r;
    out.push({
      type: 'post', id: r.pid, title: r.title, text: r.text, images: J(r.images, []), created: r.created, likes: r.likes, liked: liked.has(r.pid), fav: favs.has(r.user_id),
      reason: mode === 'foryou' ? (REASONS[s.top] || REASONS.explore)(r.cat) : null,
      author: pubPro({ id: r.user_id, nick: r.nick, name: r.name, cat: r.cat, services: r.services, city: r.city, education: r.education, experience: r.experience, about: r.about, price_text: r.price_text, price_from: r.price_from, consult_price: r.consult_price, consult_minutes: r.consult_minutes, status: r.status, inn_ok: r.inn_ok, avatar: r.avatar, rating: r.rating, reviews_n: r.reviews_n, boost: r.boost, boost_until: r.boost_until, demo: r.demo, created: r.created }),
    });
    if ((i + 1) % 5 === 0 && suggestions[si]) {
      const pr = suggestions[si++];
      const top = (interests[pr.cat] || 0) > 0 ? REASONS.interest(pr.cat) : (city && (pr.city || '').toLowerCase() === city ? REASONS.city() : REASONS.explore());
      out.push({ type: 'pro', reason: top, author: pubPro(pr) });
    }
  });
  return { items: out, total: order.length, next: offset + slice.length < order.length ? offset + slice.length : null, mode };
}

// ---------- Диалоги, заказы, платежи ----------
function sysMsg(convId, text, meta) {
  const id = q('INSERT INTO msgs(conv_id,sender_id,kind,text,meta,created) VALUES(?,?,?,?,?,?)').run(convId, 0, 'system', text, JSON.stringify(meta || {}), now()).lastInsertRowid;
  q('UPDATE convs SET last_at=? WHERE id=?').run(now(), convId);
  return Number(id);
}
function userMsg(convId, senderId, text, meta, kind) {
  const id = q('INSERT INTO msgs(conv_id,sender_id,kind,text,meta,created) VALUES(?,?,?,?,?,?)').run(convId, senderId, kind || 'text', text, JSON.stringify(meta || {}), now()).lastInsertRowid;
  q('UPDATE convs SET last_at=? WHERE id=?').run(now(), convId);
  return Number(id);
}
function convFor(clientId, proId, requestId) {
  let c = q('SELECT * FROM convs WHERE client_id=? AND pro_id=?').get(clientId, proId);
  if (!c) {
    const id = q('INSERT INTO convs(client_id,pro_id,request_id,created,last_at) VALUES(?,?,?,?,?)').run(clientId, proId, requestId || null, now(), now()).lastInsertRowid;
    c = q('SELECT * FROM convs WHERE id=?').get(id);
  } else if (requestId && !c.request_id) { q('UPDATE convs SET request_id=? WHERE id=?').run(requestId, c.id); c.request_id = requestId; }
  return c;
}
function hasPaid(convId) { return !!q("SELECT 1 x FROM orders WHERE conv_id=? AND status IN ('held','deliv','done','disp')").get(convId); }
function createOrder(conv, kind, title, amount) {
  const exists = q("SELECT id FROM orders WHERE conv_id=? AND status IN ('inv','held','deliv','disp')").get(conv.id);
  if (exists) throw bad('В этом диалоге уже есть активный заказ');
  const id = Number(q('INSERT INTO orders(conv_id,client_id,pro_id,kind,title,amount,status,created) VALUES(?,?,?,?,?,?,?,?)').run(conv.id, conv.client_id, conv.pro_id, kind, title, amount, 'inv', now()).lastInsertRowid);
  sysMsg(conv.id, `Счёт: ${title} — ${brain.rub(amount)}`, { order: id, event: 'invoice' });
  return id;
}

function applyPayment(p) {
  if (p.status === 'succeeded') return;
  tx(() => {
    q("UPDATE payments SET status='succeeded', paid_at=? WHERE id=? AND status<>'succeeded'").run(now(), p.id);
    const meta = J(p.meta, {});
    if (p.kind === 'order') {
      const o = q('SELECT * FROM orders WHERE id=?').get(p.ref);
      if (o && o.status === 'inv') {
        q("UPDATE orders SET status='held', paid_at=? WHERE id=?").run(now(), o.id);
        sysMsg(o.conv_id, `Оплата получена: ${brain.rub(o.amount)}. Деньги хранятся у платформы до подтверждения результата.`, { order: o.id, event: 'paid' });
        scheduleDemoAfterPay(o.id);
      }
    } else if (p.kind === 'sub') {
      const lvl = meta.level, months = meta.months;
      const cur = q('SELECT boost_until FROM profiles WHERE user_id=?').get(p.user_id);
      const base = Math.max(now(), cur ? cur.boost_until : 0);
      const until = base + months * 30 * 86400e3;
      q('UPDATE profiles SET boost=?, boost_until=? WHERE user_id=?').run(lvl, until, p.user_id);
      q('INSERT INTO subs(user_id,level,months,price,total,until,created) VALUES(?,?,?,?,?,?,?)').run(p.user_id, lvl, months, meta.price, p.amount, until, now());
    }
  });
}

// Пример-профили отвечают как консультанты на основе базы знаний
function demoHistory(convId) {
  const conv = q('SELECT * FROM convs WHERE id=?').get(convId);
  const h = q('SELECT sender_id, kind, text, meta FROM msgs WHERE conv_id=? ORDER BY id').all(convId).map(m => ({ from: m.kind === 'system' ? 'sys' : m.sender_id === conv.client_id ? 'client' : 'pro', text: m.text, meta: J(m.meta, {}) }));
  if (conv.request_id) { const rq = q('SELECT text,budget FROM requests WHERE id=?').get(conv.request_id); if (rq) h.unshift({ from: 'client', text: rq.text + (rq.budget ? '. Бюджет до ' + rq.budget + ' рублей' : ''), meta: { request: true } }); }
  return h;
}
const pendingDemo = new Set();
function scheduleDemoReply(convId) {
  const conv = q('SELECT * FROM convs WHERE id=?').get(convId); if (!conv) return;
  const pr = proRow(conv.pro_id); if (!pr || !pr.demo) return;
  if (pendingDemo.has(convId)) return; pendingDemo.add(convId);
  const hist = demoHistory(convId); const lastLen = (hist.filter(h => h.from === 'client').pop() || { text: '' }).text.length;
  setTimeout(() => {
    pendingDemo.delete(convId);
    try {
      const h2 = demoHistory(convId);
      if (h2.length && h2[h2.length - 1].from !== 'client') return; // уже ответили
      const profile = { name: pr.name, cat: pr.cat, price_from: pr.price_from, price_text: pr.price_text, city: pr.city, education: pr.education, experience: pr.experience };
      const r = brain.demoReply(profile, h2);
      userMsg(convId, conv.pro_id, r.text, r.meta || {});
      if (r.action && r.action.type === 'invoice') {
        try { createOrder(conv, 'order', r.action.title, r.action.amount); } catch (_) { /* уже есть заказ */ }
      }
    } catch (e) { console.error('demo reply', e.message); }
  }, 1400 + Math.min(2500, lastLen * 12));
}
function scheduleDemoAfterPay(orderId) {
  const o = q('SELECT * FROM orders WHERE id=?').get(orderId); if (!o) return;
  const pr = proRow(o.pro_id); if (!pr || !pr.demo) return;
  setTimeout(() => {
    try {
      const cur = q('SELECT * FROM orders WHERE id=?').get(orderId); if (!cur || cur.status !== 'held') return;
      const conv = q('SELECT * FROM convs WHERE id=?').get(cur.conv_id);
      const hist = demoHistory(cur.conv_id);
      const profile = { name: pr.name, cat: pr.cat, price_from: pr.price_from, price_text: pr.price_text, city: pr.city };
      if (cur.kind === 'consult') {
        const brief = brain.briefFrom(hist.filter(h => h.from === 'client').map(h => h.text), pr.cat);
        const r = brain.consultSummary(profile, brief, brain.estimate(brief, profile));
        userMsg(cur.conv_id, conv.pro_id, r.text, r.meta);
      } else userMsg(cur.conv_id, conv.pro_id, 'Работа выполнена. Проверьте результат и подтвердите получение — тогда платформа переведёт мне оплату.', {});
      q("UPDATE orders SET status='deliv' WHERE id=?").run(orderId);
      sysMsg(cur.conv_id, 'Специалист передал результат. Проверьте и подтвердите получение.', { order: orderId, event: 'delivered' });
    } catch (e) { console.error('demo deliver', e.message); }
  }, 6000);
}

// ---------- Маршруты ----------
const routes = [];
const route = (method, re, fn) => routes.push([method, re, fn]);
const needUser = ctx => { if (!ctx.user || ctx.user.demo) throw bad('Войдите в аккаунт', 401); return ctx.user; };
const ownProfile = ctx => { const u = needUser(ctx); const p = proRow(u.id); if (!p) throw bad('Сначала создайте профиль специалиста', 403); return p; };

route('GET', /^\/api\/health$/, () => ({ ok: true, payments: pay.MODE, demo: DEMO_ON, commission: COMMISSION }));

route('GET', /^\/api\/device$/, ctx => {
  const did = str(ctx.query.did, 64); if (!/^[a-z0-9]{8,64}$/i.test(did)) return { known: null };
  const r = q('SELECT u.name, u.email FROM devices d JOIN users u ON u.id=d.user_id WHERE d.did=? AND u.demo=0 ORDER BY d.last DESC LIMIT 1').get(did);
  return { known: r ? { name: r.name, email: r.email } : null };
});

route('POST', /^\/api\/register$/, ctx => {
  limit('reg:' + ctx.ip, 10, 3600e3);
  const b = ctx.body, name = str(b.name, 60), email = str(b.email, 120).toLowerCase(), pw = String(b.password || '');
  if (!name || !/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(email) || pw.length < 6 || pw.length > 200) throw bad('Укажите имя, корректный email и пароль от 6 символов');
  if (q('SELECT 1 x FROM users WHERE email=?').get(email)) throw bad('Этот email уже зарегистрирован — войдите', 409);
  const salt = crypto.randomBytes(16).toString('hex');
  const id = Number(q('INSERT INTO users(email,name,salt,hash,created) VALUES(?,?,?,?,?)').run(email, name, salt, hashPw(pw, salt), now()).lastInsertRowid);
  rememberDevice(id, b.did, b.label); newSession(ctx.res, id);
  return { ok: true, user: { id, name, email } };
});
route('POST', /^\/api\/login$/, ctx => {
  const b = ctx.body, email = str(b.email, 120).toLowerCase();
  limit('login:' + ctx.ip + ':' + email, 8, 600e3);
  const u = q('SELECT * FROM users WHERE email=? AND demo=0').get(email);
  if (!u || !checkPw(String(b.password || ''), u.salt, u.hash)) throw bad('Неверный email или пароль', 401);
  rememberDevice(u.id, b.did, b.label); newSession(ctx.res, u.id);
  return { ok: true, user: { id: u.id, name: u.name, email: u.email } };
});
route('POST', /^\/api\/logout$/, ctx => { const tk = cookies(ctx.req).sid; if (tk) q('DELETE FROM sessions WHERE token=?').run(tk); setSession(ctx.res, '', 0); return { ok: true }; });

function mePayload(u) {
  const prof = proRow(u.id);
  const unread = q(`SELECT COUNT(*) c FROM msgs m JOIN convs c ON c.id=m.conv_id LEFT JOIN reads r ON r.conv_id=c.id AND r.user_id=?
    WHERE (c.client_id=? OR c.pro_id=?) AND m.sender_id<>? AND m.sender_id<>0 AND m.id>COALESCE(r.last_id,0)`).get(u.id, u.id, u.id, u.id).c;
  const inbox = prof ? q("SELECT COUNT(*) c FROM requests r WHERE r.cat=? AND r.status='open' AND r.created>? AND r.client_id<>? AND NOT EXISTS(SELECT 1 FROM convs c WHERE c.request_id=r.id AND c.pro_id=?)").get(prof.cat, now() - 14 * 86400e3, u.id, u.id).c : 0;
  const bal = q('SELECT COALESCE(SUM(amount),0) s FROM ledger WHERE user_id=?').get(u.id).s;
  const sub = prof && prof.boost_until > now() ? { level: prof.boost, until: prof.boost_until } : null;
  return { user: { id: u.id, name: u.name, email: u.email }, profile: prof ? Object.assign(pubPro(q(`SELECT ${PRO_COLS} FROM profiles p WHERE p.user_id=?`).get(u.id)), { inn: prof.inn }) : null, unread, inbox, balance: bal, sub, tips: prof ? brain.profileTips({ avatar: prof.avatar, about: prof.about, consult_price: prof.consult_price, inn_ok: prof.inn_ok }, stats(u.id)) : [], interests: J(u.interests, {}) };
}
route('GET', /^\/api\/me$/, ctx => (ctx.user && !ctx.user.demo ? mePayload(ctx.user) : { user: null }));

route('POST', /^\/api\/me\/interests$/, ctx => {
  const u = needUser(ctx); const add = ctx.body.add || {}; const cur = J(u.interests, {});
  for (const k in cur) cur[k] *= 0.97;
  for (const k in add) { const ci = +k, v = clamp(+add[k] || 0, 0, 10); if (ci >= 0 && ci < brain.CATS.length) cur[ci] = clamp((cur[ci] || 0) + v, 0, 100); }
  if (ctx.body.set) { for (const k in ctx.body.set) { const ci = +k; if (ci >= 0 && ci < brain.CATS.length) cur[ci] = clamp(+ctx.body.set[k] || 0, 0, 100); } }
  q('UPDATE users SET interests=? WHERE id=?').run(JSON.stringify(cur), u.id);
  return { ok: true, interests: cur };
});

route('PUT', /^\/api\/profile$/, ctx => {
  const u = needUser(ctx), b = ctx.body, ex = proRow(u.id);
  const nick = str(b.nick, 30).replace(/^@/, '').toLowerCase();
  if (!/^[a-z0-9._]{3,30}$/.test(nick)) throw bad('Никнейм: 3–30 символов, латиница, цифры, точка или подчёркивание');
  const dup = q('SELECT user_id FROM profiles WHERE nick=?').get(nick); if (dup && dup.user_id !== u.id) throw bad('Такой никнейм уже занят', 409);
  const name = str(b.name, 80), services = str(b.services, 400), about = str(b.about, 2000);
  const cat = +b.cat; if (!(cat >= 0 && cat < brain.CATS.length)) throw bad('Выберите направление');
  if (!name || !services || about.length < 20) throw bad('Укажите ФИО, список услуг и описание (не короче 20 символов)');
  const status = b.status === 'ИП' ? 'ИП' : 'Самозанятый';
  const inn = str(b.inn, 12);
  if (!ex || ex.inn !== inn) { if (!validINN(inn)) throw bad('ИНН указан неверно: нужно 12 цифр (контрольная сумма не сходится)'); }
  if (!ex && b.confirmAge !== true) throw bad('Подтвердите, что вам есть 16 лет и вы самостоятельно платите налоги');
  const priceText = str(b.price_text, 80), pm = priceText.replace(/\s/g, '').match(/\d+/);
  const priceFrom = pm ? +pm[0] : 0;
  const cprice = 0; // платные консультации отключены
  if (cprice && cprice < 300) throw bad('Минимальная цена консультации — 300 ₽');
  let avatar = ex ? ex.avatar : null;
  if (b.avatar) avatar = saveImage(b.avatar);
  if (ex) {
    q('UPDATE profiles SET nick=?,name=?,cat=?,services=?,city=?,education=?,experience=?,about=?,price_text=?,price_from=?,consult_price=?,consult_minutes=?,inn=?,status=?,avatar=?,updated=?,inn_ok=CASE WHEN inn=? THEN inn_ok ELSE 0 END WHERE user_id=?')
      .run(nick, name, cat, services, str(b.city, 60) || 'Удалённо', str(b.education, 200), str(b.experience, 1000), about, priceText, priceFrom, cprice, clamp(+b.consult_minutes || 30, 15, 180), inn, status, avatar, now(), inn, u.id);
  } else {
    q('INSERT INTO profiles(user_id,nick,name,cat,services,city,education,experience,about,price_text,price_from,consult_price,consult_minutes,inn,status,avatar,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(u.id, nick, name, cat, services, str(b.city, 60) || 'Удалённо', str(b.education, 200), str(b.experience, 1000), about, priceText, priceFrom, cprice, clamp(+b.consult_minutes || 30, 15, 180), inn, status, avatar, now(), now());
  }
  if (status === 'Самозанятый' && (!ex || ex.inn !== inn)) checkNpd(u.id, inn);
  return { ok: true, profile: getPro(u.id) };
});

route('GET', /^\/api\/pros$/, ctx => {
  const cat = ctx.query.cat !== undefined && ctx.query.cat !== '' ? +ctx.query.cat : -1;
  const qs = str(ctx.query.q, 80).toLowerCase(), city = str(ctx.query.city, 60).toLowerCase();
  let rows = q(`SELECT ${PRO_COLS} FROM profiles p WHERE 1=1${demoFilter()} ORDER BY p.rating DESC, p.created DESC LIMIT 400`).all();
  if (cat >= 0) rows = rows.filter(r => r.cat === cat);
  if (city) rows = rows.filter(r => (r.city || '').toLowerCase() === city);
  if (qs) rows = rows.filter(r => (r.name + ' ' + r.services + ' ' + r.about + ' ' + brain.CATS[r.cat]).toLowerCase().includes(qs));
  return { pros: rows.slice(0, clamp(+ctx.query.limit || 100, 1, 200)).map(pubPro) };
});

route('GET', /^\/api\/pros\/(\d+)$/, ctx => {
  const id = +ctx.params[0]; const pro = getPro(id); if (!pro) throw bad('Профиль не найден', 404);
  const liked = new Set(ctx.user ? q('SELECT post_id FROM likes WHERE user_id=?').all(ctx.user.id).map(r => r.post_id) : []);
  const posts = q('SELECT id,title,text,images,created,likes FROM posts WHERE user_id=? AND deleted=0 ORDER BY created DESC LIMIT 40').all(id).map(r => ({ id: r.id, title: r.title, text: r.text, images: J(r.images, []), created: r.created, likes: r.likes, liked: liked.has(r.id) }));
  const reviews = q('SELECT author,stars,text,created FROM reviews WHERE pro_id=? ORDER BY created DESC LIMIT 12').all(id);
  return { pro, stats: stats(id), posts, reviews, following: ctx.user ? !!q('SELECT 1 x FROM follows WHERE user_id=? AND pro_id=?').get(ctx.user.id, id) : false, fav: ctx.user ? !!q('SELECT 1 x FROM favs WHERE user_id=? AND pro_id=?').get(ctx.user.id, id) : false, own: !!(ctx.user && ctx.user.id === id) };
});

route('POST', /^\/api\/pros\/(\d+)\/fav$/, ctx => {
  const u = needUser(ctx), id = +ctx.params[0]; if (id === u.id) throw bad('Нельзя добавить в избранное себя');
  if (!getPro(id)) throw bad('Профиль не найден', 404);
  const ex = q('SELECT 1 x FROM favs WHERE user_id=? AND pro_id=?').get(u.id, id);
  if (ex) q('DELETE FROM favs WHERE user_id=? AND pro_id=?').run(u.id, id); else q('INSERT INTO favs(user_id,pro_id,created) VALUES(?,?,?)').run(u.id, id, now());
  return { fav: !ex };
});
route('GET', /^\/api\/favs$/, ctx => {
  const u = needUser(ctx);
  const rows = q(`SELECT ${PRO_COLS} FROM favs f JOIN profiles p ON p.user_id=f.pro_id WHERE f.user_id=? ${demoFilter()} ORDER BY f.created DESC`).all(u.id);
  return { pros: rows.map(pubPro) };
});
route('GET', /^\/api\/orders\/mine$/, ctx => {
  const u = needUser(ctx);
  const rows = q('SELECT o.*, pc.name AS pro_name, pc.nick AS pro_nick, pc.avatar AS pro_avatar, uc.name AS client_name, r.stars AS stars FROM orders o LEFT JOIN profiles pc ON pc.user_id=o.pro_id LEFT JOIN users uc ON uc.id=o.client_id LEFT JOIN reviews r ON r.order_id=o.id WHERE o.client_id=? OR o.pro_id=? ORDER BY o.created DESC LIMIT 200').all(u.id, u.id);
  return { orders: rows.map(o => {
    const asClient = o.client_id === u.id;
    return { id: o.id, conv_id: o.conv_id, title: o.title, amount: o.amount, status: o.status, created: o.created, paid_at: o.paid_at, done_at: o.done_at, role: asClient ? 'client' : 'pro', peer: asClient ? { id: o.pro_id, name: o.pro_name, nick: o.pro_nick, avatar: o.pro_avatar } : { id: o.client_id, name: o.client_name }, stars: o.stars || 0 };
  }) };
});
route('POST', /^\/api\/pros\/(\d+)\/follow$/, ctx => {
  const u = needUser(ctx), id = +ctx.params[0]; if (id === u.id) throw bad('Нельзя подписаться на себя');
  if (!getPro(id)) throw bad('Профиль не найден', 404);
  const ex = q('SELECT 1 x FROM follows WHERE user_id=? AND pro_id=?').get(u.id, id);
  if (ex) q('DELETE FROM follows WHERE user_id=? AND pro_id=?').run(u.id, id); else q('INSERT INTO follows(user_id,pro_id) VALUES(?,?)').run(u.id, id);
  return { following: !ex };
});

route('POST', /^\/api\/posts$/, ctx => {
  const u = needUser(ctx); ownProfile(ctx); limit('post:' + u.id, 30, 86400e3);
  const text = str(ctx.body.text, 3000), title = str(ctx.body.title, 120);
  const imgs = Array.isArray(ctx.body.images) ? ctx.body.images.slice(0, 6) : [];
  if (!text && !imgs.length) throw bad('Напишите текст или добавьте фото');
  const urls = imgs.map(saveImage);
  const id = Number(q('INSERT INTO posts(user_id,title,text,images,created) VALUES(?,?,?,?,?)').run(u.id, title, text, JSON.stringify(urls), now()).lastInsertRowid);
  return { ok: true, id };
});
route('DELETE', /^\/api\/posts\/(\d+)$/, ctx => {
  const u = needUser(ctx), id = +ctx.params[0];
  const r = q('UPDATE posts SET deleted=1 WHERE id=? AND user_id=?').run(id, u.id);
  if (!r.changes) throw bad('Пост не найден', 404);
  return { ok: true };
});
route('POST', /^\/api\/posts\/(\d+)\/like$/, ctx => {
  const u = needUser(ctx), id = +ctx.params[0];
  const po = q('SELECT user_id FROM posts WHERE id=? AND deleted=0').get(id); if (!po) throw bad('Пост не найден', 404);
  const ex = q('SELECT 1 x FROM likes WHERE user_id=? AND post_id=?').get(u.id, id);
  tx(() => {
    if (ex) { q('DELETE FROM likes WHERE user_id=? AND post_id=?').run(u.id, id); q('UPDATE posts SET likes=MAX(0,likes-1) WHERE id=?').run(id); }
    else { q('INSERT INTO likes(user_id,post_id) VALUES(?,?)').run(u.id, id); q('UPDATE posts SET likes=likes+1 WHERE id=?').run(id); }
  });
  return { liked: !ex, likes: q('SELECT likes FROM posts WHERE id=?').get(id).likes };
});

route('GET', /^\/api\/feed$/, ctx => feed(ctx.user && !ctx.user.demo ? ctx.user : null, ctx.query));

// ----- Заявки клиентов -----
route('POST', /^\/api\/requests$/, ctx => {
  const u = needUser(ctx); limit('req:' + u.id, 20, 86400e3);
  const text = str(ctx.body.text, 2000), cat = +ctx.body.cat;
  if (text.length < 10) throw bad('Опишите задачу подробнее (хотя бы одно предложение)');
  if (!(cat >= 0 && cat < brain.CATS.length)) throw bad('Выберите направление');
  const id = Number(q('INSERT INTO requests(client_id,text,cat,budget,city,created) VALUES(?,?,?,?,?,?)').run(u.id, text, cat, clamp(+ctx.body.budget || 0, 0, 1e8), str(ctx.body.city, 60), now()).lastInsertRowid);
  if (DEMO_ON) scheduleDemoResponses(id);
  return { ok: true, id };
});
function scheduleDemoResponses(reqId) {
  const r = q('SELECT * FROM requests WHERE id=?').get(reqId); if (!r) return;
  const pros = q(`SELECT ${PRO_COLS} FROM profiles p WHERE p.demo=1 AND p.cat=?`).all(r.cat);
  const city = (r.city || '').toLowerCase();
  pros.sort((a, b) => ((b.city || '').toLowerCase() === city) - ((a.city || '').toLowerCase() === city) || b.rating - a.rating);
  pros.slice(0, 3).forEach((pr, i) => {
    setTimeout(() => {
      try {
        const conv = convFor(r.client_id, pr.id, r.id);
        const profile = { name: pr.name, cat: pr.cat, price_from: pr.price_from, price_text: pr.price_text, city: pr.city };
        const brief = brain.briefFrom([r.text + (r.budget ? '. Бюджет до ' + r.budget + ' рублей' : '')], pr.cat);
        const est = brain.estimate(brief, profile);
        const need = brain.missingInfo(brief, pr.cat, []).slice(0, 2);
        let t = `Здравствуйте! Меня зовут ${pr.name.split(' ')[0]}, ваша заявка как раз по моему направлению.`;
        if (brief.topic) t += ` Задача: ${brief.topic.name}.`;
        if (est && !est.needQty) t += ` Ориентир по стоимости — ${brain.rub(est.lo)}–${brain.rub(est.hi)}, по срокам: ${brief.topic.time}.`;
        else if (est) t += ` Ориентир: ${est.basis}.`;
        if (need.length) t += ' Чтобы предложить точный вариант, уточните: ' + need.map(x => x.q).join(' ');
        userMsg(conv.id, pr.id, t, { asked: need.map(x => x.id), response: true });
      } catch (e) { console.error('demo response', e.message); }
    }, 2500 + i * 3500);
  });
}
route('GET', /^\/api\/requests\/mine$/, ctx => {
  const u = needUser(ctx);
  const rows = q('SELECT * FROM requests WHERE client_id=? ORDER BY created DESC LIMIT 30').all(u.id);
  return { requests: rows.map(r => ({ id: r.id, text: r.text, cat: r.cat, budget: r.budget, city: r.city, created: r.created, status: r.status, responses: q('SELECT c.id conv_id, p.user_id pro_id, p.name, p.avatar, p.demo, p.rating, p.price_text, p.cat, (SELECT text FROM msgs m WHERE m.conv_id=c.id AND m.sender_id=c.pro_id ORDER BY m.id LIMIT 1) first FROM convs c JOIN profiles p ON p.user_id=c.pro_id WHERE c.request_id=?').all(r.id) })) };
});
route('POST', /^\/api\/requests\/(\d+)\/close$/, ctx => { const u = needUser(ctx); q("UPDATE requests SET status='closed' WHERE id=? AND client_id=?").run(+ctx.params[0], u.id); return { ok: true }; });
route('GET', /^\/api\/requests\/inbox$/, ctx => {
  const p = ownProfile(ctx), u = ctx.user;
  const rows = q("SELECT r.*, u.name client_name FROM requests r JOIN users u ON u.id=r.client_id WHERE r.status='open' AND r.created>? AND r.client_id<>? AND r.cat=? ORDER BY r.created DESC LIMIT 60").all(now() - 30 * 86400e3, u.id, p.cat);
  return { requests: rows.map(r => {
    const conv = q('SELECT id FROM convs WHERE request_id=? AND pro_id=?').get(r.id, u.id);
    const local = !r.city || (r.city || '').toLowerCase() === (p.city || '').toLowerCase() || p.city === 'Удалённо';
    const brief = brain.briefFrom([r.text], p.cat), est = brain.estimate(brief, { price_from: p.price_from });
    return { id: r.id, text: r.text, budget: r.budget, city: r.city, created: r.created, client: r.client_name.split(' ')[0], responded: conv ? conv.id : null, local, hint: est && !est.needQty ? { lo: est.lo, hi: est.hi, topic: brief.topic.name } : brief.topic ? { topic: brief.topic.name, basis: est && est.basis } : null };
  }) };
});
route('POST', /^\/api\/requests\/(\d+)\/respond$/, ctx => {
  const p = ownProfile(ctx), u = ctx.user; limit('respond:' + u.id, 60, 86400e3);
  const r = q("SELECT * FROM requests WHERE id=? AND status='open'").get(+ctx.params[0]); if (!r) throw bad('Заявка не найдена или закрыта', 404);
  if (r.client_id === u.id) throw bad('Нельзя откликнуться на свою заявку');
  const text = str(ctx.body.text, 2000); if (text.length < 10) throw bad('Напишите отклик: что и как вы предложите клиенту');
  const conv = convFor(r.client_id, u.id, r.id);
  userMsg(conv.id, u.id, hasPaid(conv.id) ? text : maskContacts(text), { response: true });
  return { ok: true, conv_id: conv.id };
});

// ----- Диалоги -----
function convView(u, c) {
  const otherId = c.client_id === u.id ? c.pro_id : c.client_id;
  const pro = getPro(c.pro_id); const other = q('SELECT id,name FROM users WHERE id=?').get(otherId);
  return { id: c.id, role: c.client_id === u.id ? 'client' : 'pro', peer: { id: otherId, name: other ? other.name : '—', pro: c.client_id === u.id ? pro : null, avatar: c.client_id === u.id && pro ? pro.avatar : null, demo: c.client_id === u.id && pro ? pro.demo : false }, request_id: c.request_id };
}
route('GET', /^\/api\/conversations$/, ctx => {
  const u = needUser(ctx);
  const rows = q('SELECT * FROM convs WHERE client_id=? OR pro_id=? ORDER BY last_at DESC LIMIT 60').all(u.id, u.id);
  return { conversations: rows.map(c => {
    const last = q('SELECT sender_id,text,kind,created FROM msgs WHERE conv_id=? ORDER BY id DESC LIMIT 1').get(c.id);
    const rd = q('SELECT last_id FROM reads WHERE conv_id=? AND user_id=?').get(c.id, u.id);
    const unread = q('SELECT COUNT(*) n FROM msgs WHERE conv_id=? AND id>? AND sender_id<>? AND sender_id<>0').get(c.id, rd ? rd.last_id : 0, u.id).n;
    const order = q('SELECT id,status,amount,kind FROM orders WHERE conv_id=? ORDER BY id DESC LIMIT 1').get(c.id) || null;
    return Object.assign(convView(u, c), { last: last ? { text: last.text, kind: last.kind, created: last.created } : null, unread, order });
  }) };
});
route('POST', /^\/api\/conversations$/, ctx => {
  const u = needUser(ctx); const proId = +ctx.body.pro_id;
  const pro = getPro(proId); if (!pro) throw bad('Специалист не найден', 404);
  if (proId === u.id) throw bad('Нельзя написать самому себе');
  const c = convFor(u.id, proId);
  const text = str(ctx.body.text, 2000);
  if (text) { limit('msg:' + u.id, 60, 60e3); userMsg(c.id, u.id, maskContacts(text), {}); scheduleDemoReply(c.id); }
  return { ok: true, id: c.id };
});
route('GET', /^\/api\/conversations\/(\d+)$/, ctx => {
  const u = needUser(ctx), id = +ctx.params[0];
  const c = q('SELECT * FROM convs WHERE id=? AND (client_id=? OR pro_id=?)').get(id, u.id, u.id); if (!c) throw bad('Диалог не найден', 404);
  const after = +ctx.query.after || 0;
  const msgs = q('SELECT id,sender_id,kind,text,meta,created FROM msgs WHERE conv_id=? AND id>? ORDER BY id').all(id, after).map(m => ({ id: m.id, mine: m.sender_id === u.id, system: m.kind === 'system', text: m.text, meta: J(m.meta, {}), created: m.created }));
  const lastId = q('SELECT COALESCE(MAX(id),0) m FROM msgs WHERE conv_id=?').get(id).m;
  q('INSERT INTO reads(conv_id,user_id,last_id) VALUES(?,?,?) ON CONFLICT(conv_id,user_id) DO UPDATE SET last_id=excluded.last_id').run(id, u.id, lastId);
  const orders = q('SELECT o.id,o.kind,o.title,o.amount,o.status,o.created,o.paid_at,(SELECT stars FROM reviews r WHERE r.order_id=o.id) stars FROM orders o WHERE conv_id=? ORDER BY id DESC').all(id);
  const view = convView(u, c);
  const out = { conv: view, messages: msgs, orders, paid: hasPaid(id), commission: COMMISSION, last_id: lastId };
  if (view.role === 'pro') {
    const pr = proRow(u.id);
    const hist = demoHistory(id).filter(h => h.from !== 'sys');
    out.assist = brain.assist({ name: pr.name, cat: pr.cat, price_from: pr.price_from }, hist);
    if (c.request_id) { const rq = q('SELECT text,budget,city FROM requests WHERE id=?').get(c.request_id); out.request = rq || null; }
  }
  if (view.role === 'client' && c.request_id) out.request = q('SELECT text,budget,city FROM requests WHERE id=?').get(c.request_id) || null;
  return out;
});
route('POST', /^\/api\/conversations\/(\d+)\/messages$/, ctx => {
  const u = needUser(ctx), id = +ctx.params[0]; limit('msg:' + u.id, 60, 60e3);
  const c = q('SELECT * FROM convs WHERE id=? AND (client_id=? OR pro_id=?)').get(id, u.id, u.id); if (!c) throw bad('Диалог не найден', 404);
  const text = str(ctx.body.text, 2000); if (!text) throw bad('Пустое сообщение');
  const masked = hasPaid(id) ? text : maskContacts(text);
  const mid = userMsg(id, u.id, masked, {});
  if (c.client_id === u.id) scheduleDemoReply(id);
  return { ok: true, id: mid, masked: masked !== text };
});
route('POST', /^\/api\/conversations\/(\d+)\/invoice$/, ctx => {
  const p = ownProfile(ctx), u = ctx.user, id = +ctx.params[0];
  const c = q('SELECT * FROM convs WHERE id=? AND pro_id=?').get(id, u.id); if (!c) throw bad('Диалог не найден', 404);
  const amount = Math.round(+ctx.body.amount), title = str(ctx.body.title, 120) || 'Услуга';
  if (!(amount >= 100 && amount <= 500000)) throw bad('Сумма счёта: от 100 до 500 000 ₽');
  const oid = createOrder(c, 'order', title, amount);
  return { ok: true, order: oid };
});
function orderFor(ctx, id, role) {
  const u = needUser(ctx); const o = q('SELECT * FROM orders WHERE id=?').get(id);
  if (!o || (role === 'client' ? o.client_id !== u.id : o.pro_id !== u.id)) throw bad('Заказ не найден', 404);
  return o;
}
route('POST', /^\/api\/orders\/(\d+)\/pay$/, async ctx => {
  const o = orderFor(ctx, +ctx.params[0], 'client');
  if (o.status !== 'inv') throw bad('Этот счёт уже оплачен или закрыт');
  const pr = proRow(o.pro_id);
  if (pr && pr.demo && pay.MODE !== 'test') throw bad('Это пример-профиль: заказы у примеров недоступны в рабочем режиме');
  limit('pay:' + o.client_id, 20, 3600e3);
  const pid = crypto.randomBytes(8).toString('hex');
  const ret = `/?pay=return&conv=${o.conv_id}`;
  const r = await pay.create({ paymentId: pid, amount: o.amount, description: `ПААРИ: ${o.title} (заказ №${o.id})`, returnPath: ret });
  q('INSERT INTO payments(id,kind,ref,user_id,amount,provider_id,created,meta) VALUES(?,?,?,?,?,?,?,?)').run(pid, 'order', o.id, o.client_id, o.amount, r.providerId, now(), JSON.stringify({ ret }));
  return { ok: true, url: r.url, mode: pay.MODE };
});
route('POST', /^\/api\/orders\/(\d+)\/deliver$/, ctx => {
  const o = orderFor(ctx, +ctx.params[0], 'pro');
  if (o.status !== 'held') throw bad('Передать результат можно после оплаты');
  q("UPDATE orders SET status='deliv' WHERE id=?").run(o.id);
  sysMsg(o.conv_id, 'Специалист передал результат. Проверьте и подтвердите получение.', { order: o.id, event: 'delivered' });
  return { ok: true };
});
route('POST', /^\/api\/orders\/(\d+)\/confirm$/, ctx => {
  const o = orderFor(ctx, +ctx.params[0], 'client');
  if (o.status !== 'deliv') throw bad('Подтвердить можно после того, как специалист передал результат');
  const fee = Math.round(o.amount * COMMISSION), net = o.amount - fee;
  tx(() => {
    q("UPDATE orders SET status='done', done_at=? WHERE id=?").run(now(), o.id);
    q('INSERT INTO ledger(user_id,order_id,amount,fee,created) VALUES(?,?,?,?,?)').run(o.pro_id, o.id, net, fee, now());
    sysMsg(o.conv_id, `Получение подтверждено. Платформа удержала комиссию ${Math.round(COMMISSION * 100)}% (${brain.rub(fee)}), специалисту к выплате ${brain.rub(net)}.`, { order: o.id, event: 'done' });
  });
  return { ok: true, net, fee };
});
route('POST', /^\/api\/orders\/(\d+)\/dispute$/, ctx => {
  const o = orderFor(ctx, +ctx.params[0], 'client');
  if (!['held', 'deliv'].includes(o.status)) throw bad('Спор можно открыть, пока вы не подтвердили получение');
  const reason = str(ctx.body.reason, 1000); if (reason.length < 5) throw bad('Опишите проблему');
  q("UPDATE orders SET status='disp' WHERE id=?").run(o.id);
  q('INSERT INTO reports(user_id,kind,ref,reason,created) VALUES(?,?,?,?,?)').run(o.client_id, 'dispute', o.id, reason, now());
  sysMsg(o.conv_id, 'Открыт спор. Деньги заморожены, поддержка свяжется с обеими сторонами.', { order: o.id, event: 'dispute' });
  return { ok: true };
});
route('POST', /^\/api\/orders\/(\d+)\/review$/, ctx => {
  const o = orderFor(ctx, +ctx.params[0], 'client');
  if (o.status !== 'done') throw bad('Отзыв можно оставить после завершённой сделки');
  if (q('SELECT 1 x FROM reviews WHERE order_id=?').get(o.id)) throw bad('Отзыв уже оставлен');
  const stars = clamp(Math.round(+ctx.body.stars || 5), 1, 5), text = str(ctx.body.text, 1000);
  q('INSERT INTO reviews(order_id,pro_id,client_id,author,stars,text,created) VALUES(?,?,?,?,?,?,?)').run(o.id, o.pro_id, o.client_id, ctx.user.name.split(' ')[0], stars, text, now());
  recalcRating(o.pro_id);
  return { ok: true };
});

// ----- Подписка на продвижение -----
route('POST', /^\/api\/subscribe$/, async ctx => {
  const u = needUser(ctx); ownProfile(ctx);
  const months = +ctx.body.months, price = +ctx.body.price;
  if (![1, 6, 12].includes(months) || !(price >= 300 && price <= 1000 && price % 100 === 0)) throw bad('Выберите срок 1/6/12 месяцев и цену от 300 до 1000 ₽ с шагом 100');
  const disc = months === 12 ? 10 : months === 6 ? 5 : 0;
  const total = Math.round(price * months * (100 - disc) / 100);
  const level = price >= 800 ? 3 : price >= 500 ? 2 : 1;
  const pid = crypto.randomBytes(8).toString('hex'); const ret = '/?pay=sub';
  const r = await pay.create({ paymentId: pid, amount: total, description: `ПААРИ: продвижение профиля, ${months} мес.`, returnPath: ret });
  q('INSERT INTO payments(id,kind,ref,user_id,amount,provider_id,created,meta) VALUES(?,?,?,?,?,?,?,?)').run(pid, 'sub', 0, u.id, total, r.providerId, now(), JSON.stringify({ ret, level, months, price }));
  return { ok: true, url: r.url, total };
});

route('POST', /^\/api\/report$/, ctx => {
  const u = needUser(ctx); limit('rep:' + u.id, 20, 3600e3);
  q('INSERT INTO reports(user_id,kind,ref,reason,created) VALUES(?,?,?,?,?)').run(u.id, str(ctx.body.kind, 20), +ctx.body.ref || 0, str(ctx.body.reason, 500), now());
  return { ok: true };
});

// ----- Тестовая страница оплаты СБП и вебхук -----
function testPayPage(p) {
  const meta = J(p.meta, {});
  return `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Оплата по СБП — тестовый режим</title>
<style>body{margin:0;font-family:Inter,system-ui,sans-serif;background:#f1f6ff;color:#0f1b33;display:grid;place-items:center;min-height:100vh;padding:16px}
.c{background:#fff;border-radius:22px;box-shadow:0 20px 50px #2563eb26;padding:26px;max-width:420px;width:100%}.t{display:inline-block;background:#fff3c4;color:#8a6500;border-radius:99px;padding:4px 12px;font-size:12px;font-weight:700}
h1{font-size:22px;margin:14px 0 4px}.s{font-size:34px;font-weight:800;background:linear-gradient(90deg,#2563eb,#7c3aed,#ec4899);-webkit-background-clip:text;background-clip:text;color:transparent;margin:8px 0}
p{color:#5b6b88;font-size:14px}button{width:100%;border:0;border-radius:14px;padding:14px;font:700 16px inherit;cursor:pointer;margin-top:10px}.ok{background:linear-gradient(135deg,#2563eb,#6d4aff);color:#fff}.no{background:#eef2fb;color:#0f1b33}</style></head>
<body><div class="c"><span class="t">ТЕСТОВЫЙ РЕЖИМ · деньги не списываются</span><h1>Оплата через СБП</h1><p>${String(p.kind === 'sub' ? 'Продвижение профиля' : 'Заказ на платформе ПААРИ')}</p><div class="s">${Number(p.amount).toLocaleString('ru-RU')} ₽</div>
<p>В боевом режиме здесь откроется приложение вашего банка или QR-код СБП. Сейчас нажмите кнопку, чтобы имитировать успешную оплату.</p>
<form method="post" action="/pay/${p.id}/confirm"><button class="ok">Оплатить через СБП (тест)</button></form>
<form method="post" action="/pay/${p.id}/cancel"><button class="no">Отмена</button></form></div></body></html>`;
}
route('GET', /^\/pay\/([a-f0-9]{16})$/, ctx => {
  if (pay.MODE !== 'test') throw bad('Недоступно', 404);
  const p = q('SELECT * FROM payments WHERE id=?').get(ctx.params[0]); if (!p) throw bad('Платёж не найден', 404);
  if (p.status === 'succeeded') return { redirect: J(p.meta, {}).ret || '/' };
  return testPayPage(p);
});
route('POST', /^\/pay\/([a-f0-9]{16})\/(confirm|cancel)$/, ctx => {
  if (pay.MODE !== 'test') throw bad('Недоступно', 404);
  const p = q('SELECT * FROM payments WHERE id=?').get(ctx.params[0]); if (!p) throw bad('Платёж не найден', 404);
  const meta = J(p.meta, {});
  if (ctx.params[1] === 'confirm') applyPayment(p);
  else q("UPDATE payments SET status='canceled' WHERE id=? AND status='pending'").run(p.id);
  return { redirect: (meta.ret || '/') + (ctx.params[1] === 'cancel' ? (meta.ret && meta.ret.includes('?') ? '&' : '?') + 'canceled=1' : '') };
});
route('POST', /^\/api\/pay\/webhook$/, async ctx => {
  if (pay.MODE !== 'yookassa') return { ok: true };
  const obj = ctx.body && ctx.body.object; if (!obj || !obj.id) return { ok: true };
  const p = q('SELECT * FROM payments WHERE provider_id=?').get(obj.id); if (!p) return { ok: true };
  const st = await pay.status(obj.id); // перепроверяем у провайдера, а не доверяем телу запроса
  if (st && st.paid) applyPayment(p);
  return { ok: true };
});
// Возврат пользователя после оплаты: добираем статус у провайдера, если вебхук ещё не пришёл
route('POST', /^\/api\/pay\/sync$/, async ctx => {
  const u = needUser(ctx);
  const rows = q("SELECT * FROM payments WHERE user_id=? AND status='pending' AND created>?").all(u.id, now() - 86400e3);
  for (const p of rows) { if (pay.MODE === 'yookassa') { try { const st = await pay.status(p.provider_id); if (st && st.paid) applyPayment(p); } catch (_) { /* ignore */ } } }
  return { ok: true };
});

// ---------- Демо-данные ----------
function seedDemo() {
  if (!DEMO_ON) return;
  if (q('SELECT COUNT(*) c FROM users WHERE demo=1').get().c) return;
  tx(() => {
    seed.PROS.forEach((d, i) => {
      const [name, cat, price, city, rating, edu, about, nick] = d;
      const uid = Number(q('INSERT INTO users(email,name,demo,created) VALUES(?,?,1,?)').run(`demo${i + 1}@paari.demo`, name, now() - 30 * 86400e3).lastInsertRowid);
      const consult = 0;
      q('INSERT INTO profiles(user_id,nick,name,cat,services,city,education,experience,about,price_text,price_from,consult_price,consult_minutes,inn,status,inn_ok,rating,reviews_n,demo,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)')
        .run(uid, nick, name, cat, about, city, edu, '', about + ' Работаю по договорённости, всегда на связи и объясняю, из чего складывается цена.', 'от ' + price, price, consult, 30, '000000000000', i % 2 ? 'ИП' : 'Самозанятый', 1, rating, 3 + (i % 4), now() - 30 * 86400e3, now());
      const rnd = mulberry(hstr(name));
      const tpl = seed.POSTS[cat].slice();
      const nPosts = 3 + (i % 2);
      for (let k = 0; k < nPosts && tpl.length; k++) {
        const t = tpl.splice(Math.floor(rnd() * tpl.length), 1)[0];
        const ageH = 3 + rnd() * 220;
        q('INSERT INTO posts(user_id,title,text,images,created,likes) VALUES(?,?,?,?,?,?)').run(uid, t[0], t[1].replace(/­/g, ''), '[]', now() - ageH * 3600e3, Math.floor(rnd() * 40));
      }
      for (let k = 0; k < 3; k++) { const rv = seed.REVIEWS[(i + k) % seed.REVIEWS.length]; q('INSERT INTO reviews(order_id,pro_id,client_id,author,stars,text,created) VALUES(NULL,?,?,?,?,?,?)').run(uid, uid, rv[0], rv[2], rv[1], now() - (k + 1) * 5 * 86400e3); }
    });
  });
  console.log('Добавлены пример-профили:', seed.PROS.length);
}
seedDemo();
db.exec('UPDATE profiles SET consult_price=0 WHERE consult_price<>0');

// ---------- Статика ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json', '.txt': 'text/plain; charset=utf-8' };
function serveStatic(req, res, urlPath) {
  let base = PUBLIC, rel = urlPath;
  if (urlPath.startsWith('/uploads/')) { base = UPLOADS; rel = urlPath.slice('/uploads'.length); }
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.normalize(path.join(base, decodeURIComponent(rel)));
  if (!file.startsWith(base + path.sep) && file !== base) { res.writeHead(403); return res.end('Forbidden'); }
  fs.stat(file, (e, st) => {
    if (e || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Не найдено'); }
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': base === UPLOADS ? 'public, max-age=31536000, immutable' : 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    fs.createReadStream(file).pipe(res);
  });
}

// ---------- Сервер ----------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const ctx = { req, res, user: null, ip: String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim(), query: Object.fromEntries(url.searchParams), params: [], body: {} };
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'same-origin'); res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  try {
    const isApi = url.pathname.startsWith('/api/') || url.pathname.startsWith('/pay/');
    if (!isApi) { if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, { error: 'Метод не поддерживается' }); return serveStatic(req, res, url.pathname); }
    let handler = null;
    for (const [m, re, fn] of routes) { const mm = re.exec(url.pathname); if (m === req.method && mm) { handler = fn; ctx.params = mm.slice(1); break; } }
    if (!handler) return send(res, 404, { error: 'Не найдено' });
    ctx.user = userFrom(req);
    if (req.method !== 'GET') {
      const ct = String(req.headers['content-type'] || '');
      const isForm = url.pathname.startsWith('/pay/');
      if (!isForm) {
        const origin = req.headers.origin; if (origin && new URL(origin).host !== req.headers.host) throw bad('Запрос отклонён', 403);
        if (ct.includes('application/json')) { const raw = await readBody(req, 12 * 1024 * 1024); ctx.body = raw ? J(raw, null) : {}; if (ctx.body === null) throw bad('Неверный JSON'); }
        else if (req.method !== 'DELETE' && !url.pathname.endsWith('/logout')) throw bad('Ожидается JSON', 415);
      } else await readBody(req, 4096);
    }
    const r = await handler(ctx);
    if (r && r.redirect) { res.writeHead(303, { Location: r.redirect }); return res.end(); }
    if (typeof r === 'string') return send(res, 200, r);
    return send(res, 200, r === undefined ? { ok: true } : r);
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.code, { error: e.message });
    console.error(e);
    return send(res, 500, { error: 'Ошибка сервера' });
  }
});

if (require.main === module) server.listen(PORT, () => console.log(`ПААРИ запущен: http://localhost:${PORT}  (оплата: ${pay.MODE}, пример-профили: ${DEMO_ON ? 'вкл' : 'выкл'})`));
module.exports = { server, db };
