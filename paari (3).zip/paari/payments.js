'use strict';
/*
 * Платёжный слой. Провайдеры:
 *  - test     — тестовый режим: страница «оплаты по СБП» на нашем сервере, деньги не списываются (по умолчанию);
 *  - yookassa — ЮKassa (СБП/карты), включается переменными YOOKASSA_SHOP_ID и YOOKASSA_SECRET_KEY.
 * Адаптер ЮKassa написан по документации API v3, но НЕ проверялся на боевом магазине — прогоните в тестовом магазине ЮKassa.
 */
const crypto = require('node:crypto');

const MODE = process.env.YOOKASSA_SHOP_ID && process.env.YOOKASSA_SECRET_KEY ? 'yookassa' : 'test';
const BASE_URL = (process.env.PUBLIC_URL || '').replace(/\/$/, '');

async function yk(method, path, body, idem) {
  const auth = Buffer.from(process.env.YOOKASSA_SHOP_ID + ':' + process.env.YOOKASSA_SECRET_KEY).toString('base64');
  const r = await fetch('https://api.yookassa.ru/v3' + path, {
    method,
    headers: Object.assign({ Authorization: 'Basic ' + auth, 'Content-Type': 'application/json' }, idem ? { 'Idempotence-Key': idem } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error('YooKassa: ' + (j.description || r.status));
  return j;
}

// Создаёт платёж у провайдера. Возвращает { providerId, url }.
async function create({ paymentId, amount, description, returnPath }) {
  if (MODE === 'yookassa') {
    const j = await yk('POST', '/payments', {
      amount: { value: amount.toFixed(2), currency: 'RUB' },
      capture: true,
      payment_method_data: { type: 'sbp' },
      confirmation: { type: 'redirect', return_url: BASE_URL + returnPath },
      description: String(description).slice(0, 128),
      metadata: { payment_id: paymentId },
    }, paymentId);
    return { providerId: j.id, url: j.confirmation && j.confirmation.confirmation_url };
  }
  return { providerId: 'test_' + crypto.randomBytes(6).toString('hex'), url: '/pay/' + paymentId };
}

// Проверяет статус у провайдера (для вебхука/возврата пользователя)
async function status(providerId) {
  if (MODE === 'yookassa') {
    const j = await yk('GET', '/payments/' + providerId);
    return { paid: j.status === 'succeeded', canceled: j.status === 'canceled', raw: j.status };
  }
  return null; // в тестовом режиме статус меняется нашей страницей
}

module.exports = { MODE, create, status };
