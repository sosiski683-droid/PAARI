/* ПААРИ — клиентская часть в режиме сервера (реальные аккаунты, профили, блог, лента, чаты, оплата).
   Если сервер недоступен (сайт открыт как файл), этот скрипт ничего не меняет, и работает старый демо-прототип. */
(function () {
  if (location.protocol === 'file:') return;
  var S = { me: null, health: null, convPoll: null, listPoll: null, feed: null };
  var PA = window.PA = {};
  var OV = {};

  function api(method, url, body) {
    return fetch(url, { method: method, credentials: 'same-origin', headers: body !== undefined ? { 'content-type': 'application/json' } : {}, body: body !== undefined ? JSON.stringify(body) : undefined })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) { var e = new Error(j.error || ('Ошибка ' + r.status)); e.status = r.status; throw e; } return j; }); });
  }
  function el(id) { return document.getElementById(id); }
  function E(t) { return window.esc(t); }
  function money(n) { return Number(n || 0).toLocaleString('ru-RU') + ' ₽'; }
  function CATN(i) { return (window.CATS || [])[i] || ''; }
  function ago(ts) {
    var s = Math.max(1, Math.round((Date.now() - ts) / 1000));
    if (s < 60) return 'только что'; var m = Math.round(s / 60); if (m < 60) return m + ' мин назад';
    var h = Math.round(m / 60); if (h < 24) return h + ' ч назад'; var d = Math.round(h / 24); if (d < 8) return d + ' дн назад';
    return new Date(ts).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' });
  }
  function lsGet(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  function say(t) { window.toast(t); }
  function errToast(e) { say(e && e.message ? e.message : 'Что-то пошло не так'); }
  function btnBusy(b, on) { if (b) { b.disabled = !!on; b.style.opacity = on ? '.6' : ''; } }

  // ---------- Интересы (для персональной ленты) ----------
  function localInt() { return lsGet('int', {}); }
  function intParam() { var o = localInt(), a = []; for (var k in o) if (o[k] > 0) a.push(k + ':' + (Math.round(o[k] * 100) / 100)); return a.join(','); }
  function bump(cat, w) {
    if (cat === undefined || cat === null || cat < 0) return;
    var o = localInt(); for (var k in o) o[k] = o[k] * 0.97;
    o[cat] = Math.min(100, (o[cat] || 0) + w); lsSet('int', o);
    if (S.me) { var add = {}; add[cat] = w; api('POST', '/api/me/interests', { add: add }).catch(function () {}); }
  }
  PA.bump = bump;

  // ---------- Данные ----------
  function legacy(p) {
    return { n: p.name, c: p.cat, p: p.price_from || 0, ps: p.price_text || '', city: p.city, r: p.rating, e: p.education, d: p.about, uid: p.id, demo: p.demo, av: p.avatar, nick: p.nick, vf: 'ok', real: !p.demo };
  }
  function loadPros() {
    return api('GET', '/api/pros?limit=200').then(function (r) { window.PROS = r.pros.map(legacy); }).catch(function () {});
  }
  function loadMe() {
    return api('GET', '/api/me').then(function (r) {
      S.me = r.user ? r : null;
      window.U = r.user ? { name: r.user.name, email: r.user.email, id: r.user.id } : null;
      window.INB = r.user ? new Array((r.unread || 0) + (r.inbox || 0)) : [];
      window.acc();
      return S.me;
    }).catch(function () { return null; });
  }
  function needLogin(after, msg) {
    if (S.me) return true;
    window._after = after; say(msg || 'Войдите или зарегистрируйтесь, чтобы продолжить');
    window.authOpen(); return false;
  }
  PA.needLogin = needLogin;

  // ---------- Аватары ----------
  OV.avt = function (p, big) {
    var x;
    if (p.av) x = '<img class="avi" alt="" src="' + E(p.av) + '">';
    else if (p.demo) x = window.face(p.n);
    else x = E((p.n || '?')[0].toUpperCase());
    return '<div class="av' + (big ? ' big' : '') + ((p.av || p.demo) ? '' : ' dflt') + '">' + x + '</div>';
  };
  function avFromPro(p, big) { return window.avt({ n: p.name, av: p.avatar, demo: p.demo }, big); }

  // ---------- Стили ----------
  var css = document.createElement('style');
  css.textContent = [
    '.srv-tabs{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}',
    '.pc2{padding:0;overflow:hidden;margin-bottom:16px;border-radius:20px}.pc2 .hd{display:flex;gap:10px;align-items:center;padding:12px 14px}.pc2 .hd .who{flex:1;min-width:0;cursor:pointer}',
    '.pc2 .bd{padding:0 14px 8px}.pc2 .bd h3{margin:0 0 4px;font-size:17px}.pc2 .bd p{margin:0 0 8px;white-space:pre-wrap;word-break:break-word;font-size:15px}',
    '.pc2 .ft{display:flex;gap:8px;flex-wrap:wrap;align-items:center;padding:8px 14px 14px}.pc2 .md{width:100%}.pc2 .md img{width:100%;display:block;max-height:520px;object-fit:cover}',
    '.badge2{display:inline-block;font-size:11px;font-weight:700;border-radius:99px;padding:2px 8px;margin-left:4px;vertical-align:middle}.b-demo{background:#eef2fb;color:#5b6b88}.b-real{background:#d9f5ee;color:#0d7a6b}.b-ver{background:#e3edff;color:#2563eb}.b-boost{background:#fff3c4;color:#8a6500}',
    '.why{display:inline-block;font-size:11.5px;color:var(--mu);background:var(--soft);border-radius:99px;padding:2px 9px;margin-top:3px}',
    '.likeb{border:1px solid var(--bd);background:#fff;border-radius:999px;padding:6px 12px;font:600 14px inherit;font-family:inherit;cursor:pointer;color:var(--mu)}.likeb.on{color:#e0245e;border-color:#f7b6c9;background:#fff0f5}',
    '.sug{border:2px solid transparent;background:linear-gradient(#fff,#fff) padding-box,linear-gradient(90deg,#2563eb,#7c3aed,#ec4899) border-box}.sug .lab{font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--ac);padding:12px 14px 0}',
    '.onb{background:linear-gradient(135deg,#f3f0ff,#fff0f7);border-radius:20px;padding:16px;margin:12px 0}.onb h3{margin:0 0 4px}',
    '.chp.sel{background:linear-gradient(135deg,#2563eb,#6d4aff);color:#fff;border-color:transparent}',
    '#prof .box,#cv .box{max-width:760px}.phead{display:flex;gap:16px;align-items:center;flex-wrap:wrap}.phead .info{flex:1;min-width:220px}.phead h2{margin:0}',
    '.kpi{display:flex;gap:18px;flex-wrap:wrap;margin:12px 0}.kpi div{font-size:13px;color:var(--mu)}.kpi b{display:block;font-size:20px;color:var(--tx)}',
    '.comp{background:var(--soft);border-radius:16px;padding:14px;margin:14px 0}.comp textarea{min-height:70px}.thumbs{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.thumbs img{width:72px;height:72px;object-fit:cover;border-radius:10px}',
    '.tipsb{background:#fff8e1;border-radius:14px;padding:12px 14px;margin:12px 0;font-size:14px}.tipsb li{margin:4px 0}',
    '.m.sys{align-self:center;background:#eef2fb;color:#5b6b88;font-size:13px;text-align:center;max-width:92%}',
    '.ord{background:#fff;border:1px solid var(--bd);border-radius:14px;padding:12px 14px;margin:10px 0}.ord .row{margin-top:8px}',
    '.assist{background:linear-gradient(135deg,#f3f0ff,#f1f6ff);border-radius:16px;padding:14px;margin:12px 0}.assist h4{margin:0 0 6px;font-size:15px}.assist .qs{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}',
    '.assist button.q{border:1px solid var(--bd);background:#fff;border-radius:12px;padding:6px 10px;font:500 13px inherit;font-family:inherit;text-align:left;cursor:pointer}.assist button.q:hover{background:var(--ac2)}',
    '.lst .it{display:flex;gap:12px;align-items:center;padding:10px 0;border-bottom:1px solid var(--bd);cursor:pointer}.lst .it:last-child{border:0}.lst .it .tx{flex:1;min-width:0}.lst .it .tx p{margin:2px 0 0;color:var(--mu);font-size:13.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.unr{background:#e0245e;color:#fff;border-radius:99px;font-size:12px;font-weight:700;padding:1px 7px;margin-left:6px}',
    '.rq{border:1px solid var(--bd);border-radius:14px;padding:12px 14px;margin-bottom:10px;background:#fff}.rq p{margin:0 0 6px}.rsp{display:flex;gap:10px;align-items:flex-start;padding:8px 0;border-top:1px dashed var(--bd);cursor:pointer}',
    '.stars{color:#f5b800;letter-spacing:1px}',
    '.srvnote{font-size:12.5px;color:var(--mu)}',
    '.car2{display:flex;overflow-x:auto;scroll-snap-type:x mandatory}.car2 img{flex:0 0 100%;width:100%;aspect-ratio:4/3;object-fit:cover;scroll-snap-align:start}'
  ].join('');
  document.head.appendChild(css);

  PA.api = api; PA.S = S; PA.el = el; PA.E = E; PA.money = money; PA.ago = ago; PA.say = say; PA.errToast = errToast; PA.btnBusy = btnBusy; PA.loadMe = loadMe; PA.loadPros = loadPros;
  PA.avFromPro = avFromPro; PA.CATN = CATN; PA.lsGet = lsGet; PA.lsSet = lsSet; PA.legacy = legacy;

  // ---------- Авторизация ----------
  OV.authOpen = function () {
    window.go('auth');
    api('GET', '/api/device?did=' + encodeURIComponent(window.devId())).then(function (r) {
      var k = r.known;
      if (k) {
        window.authTab('l'); el('le').value = k.email;
        el('aWel').innerHTML = 'С возвращением, <b class="gt">' + E(k.name) + '</b>! Это устройство вам знакомо — просто введите пароль.'; el('aWel').style.display = 'block';
      } else { window.authTab('r'); el('aWel').style.display = 'none'; }
    }).catch(function () { window.authTab('r'); });
  };
  OV.enter = function (w) {
    window.W = w;
    if (S.me) { if (w === 'pro') { S.me.profile ? PA.openPro(S.me.profile.id) : window.go('pro'); } else if (w === 'client') window.go('cl'); else window.go('me'); }
    else window.authOpen();
  };
  function afterAuth() {
    return Promise.all([loadMe(), loadPros()]).then(function () {
      var f = window._after; window._after = null;
      if (f) { f(); return; }
      var w = window.W;
      if (w === 'pro') { S.me && S.me.profile ? PA.openPro(S.me.profile.id) : window.go('pro'); } else if (w === 'client') window.go('cl'); else window.go('me');
    });
  }
  OV.reg = function () {
    var n = el('rn').value.trim(), e = el('re').value.trim(), p = el('rp').value;
    if (!n || !/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(e) || p.length < 6) { say('Укажите имя, корректный email и пароль от 6 символов'); return; }
    api('POST', '/api/register', { name: n, email: e, password: p, did: window.devId(), label: window.devLabel() }).then(function () { say('Регистрация прошла успешно. Добро пожаловать!'); return afterAuth(); }).catch(function (er) {
      if (er.status === 409) { window.authTab('l'); el('le').value = e; } errToast(er);
    });
  };
  OV.login = function () {
    var e = el('le').value.trim(), p = el('lp').value;
    api('POST', '/api/login', { email: e, password: p, did: window.devId(), label: window.devLabel() }).then(function () { el('lp').value = ''; return afterAuth(); }).catch(errToast);
  };
  OV.logout = function () {
    api('POST', '/api/logout', {}).finally(function () { S.me = null; window.U = null; window.INB = []; window.acc(); window.go('home'); });
  };
  OV.acc = function () {
    var a = el('acc'); if (!a) return;
    var n = S.me ? (S.me.unread || 0) + (S.me.inbox || 0) : 0;
    a.innerHTML = S.me ? '<b>👤 ' + E(S.me.user.name.split(' ')[0]) + (n ? ' <span class="unr">' + n + '</span>' : '') + '</b>' : '<b class="loginb">Войти</b>';
  };

  // ---------- Сжатие изображений ----------
  function shrinkImg(file, max, qual) {
    return new Promise(function (res, rej) {
      if (!/^image\//.test(file.type)) return rej(new Error('Нужно изображение (JPEG, PNG или WebP)'));
      var r = new FileReader();
      r.onload = function () {
        var im = new Image();
        im.onload = function () {
          var s = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(im.width * s)); c.height = Math.max(1, Math.round(im.height * s));
          c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', qual));
        };
        im.onerror = function () { rej(new Error('Не удалось прочитать изображение. Попробуйте JPEG или PNG')); };
        im.src = r.result;
      };
      r.onerror = function () { rej(new Error('Не удалось прочитать файл')); };
      r.readAsDataURL(file);
    });
  }
  PA.shrinkImg = shrinkImg;

  // ---------- Карточки ----------
  function badges(a) {
    return (a.demo ? '<span class="badge2 b-demo" title="Пример-профиль для демонстрации">Пример</span>' : '<span class="badge2 b-real">Реальный</span>') +
      (a.verified ? '<span class="badge2 b-ver">✔ проверен</span>' : '') + (a.boost ? '<span class="badge2 b-boost">★ продвигается</span>' : '');
  }
  function media(it) {
    var imgs = it.images || [];
    if (imgs.length > 1) return '<div class="md"><div class="car2">' + imgs.map(function (s) { return '<img alt="" loading="lazy" src="' + E(s) + '" onclick="PA.zoom(this.src)">'; }).join('') + '</div><div class="tag" style="padding:4px 14px 0">📷 ' + imgs.length + ' фото, листайте →</div></div>';
    if (imgs.length === 1) return '<div class="md"><img alt="" loading="lazy" src="' + E(imgs[0]) + '" onclick="PA.zoom(this.src)"></div>';
    if (it.author && it.author.demo && window.art) return '<div class="md"><div class="cov art" style="height:auto;aspect-ratio:16/9;font-size:0">' + window.art(it.author.cat, it.id % 3) + '</div></div>';
    return '';
  }
  PA.zoom = function (src) { var lb = el('lb'); if (lb) { lb.innerHTML = '<img alt="" src="' + E(src) + '">'; lb.style.display = 'flex'; lb.onclick = function () { lb.style.display = 'none'; }; } };
  function proActions(a) {
    var c = '';
    return '<button class="btn s" onclick="PA.openPro(' + a.id + ')">Профиль</button><button class="btn o s" onclick="PA.write(' + a.id + ')">Написать</button>' + c;
  }
  function postCard(it, opt) {
    opt = opt || {}; var a = it.author;
    var head = opt.noHead ? '' : '<div class="hd">' + avFromPro(a) + '<div class="who" onclick="PA.openPro(' + a.id + ')"><b>' + E(a.name) + '</b>' + badges(a) + '<div class="tag">' + E(CATN(a.cat)) + ' · ' + E(a.city) + ' · ' + ago(it.created) + '</div>' + (it.reason ? '<span class="why">✨ ' + E(it.reason) + '</span>' : '') + '</div></div>';
    var del = opt.own ? '<button class="likeb" onclick="PA.delPost(' + it.id + ')">🗑 Удалить</button>' : '';
    var acts = opt.noActions ? '' : proActions(a) + (opt.own ? '' : '<button class="likeb" data-fav="' + a.id + '" onclick="PA.fav(' + a.id + ',this)">' + (it.fav ? '★ В избранном' : '☆ В избранное') + '</button>');
    return '<div class="card pc2" id="post' + it.id + '">' + head + media(it) +
      '<div class="bd" style="padding-top:12px">' + (it.title ? '<h3>' + E(it.title) + '</h3>' : '') + (it.text ? '<p>' + E(it.text) + '</p>' : '') + '</div>' +
      '<div class="ft"><button class="likeb' + (it.liked ? ' on' : '') + '" onclick="PA.like(' + it.id + ',this,' + a.cat + ')">' + (it.liked ? '♥' : '♡') + ' <span>' + it.likes + '</span></button>' + acts + del + '</div></div>';
  }
  function sugCard(it) {
    var a = it.author;
    return '<div class="card pc2 sug"><div class="lab">Рекомендуем специалиста' + (it.reason ? ' · ' + E(it.reason) : '') + '</div><div class="hd">' + avFromPro(a) + '<div class="who" onclick="PA.openPro(' + a.id + ')"><b>' + E(a.name) + '</b>' + badges(a) + '<div class="tag">' + E(CATN(a.cat)) + ' · ' + E(a.city) + (a.rating ? ' · ★ ' + a.rating : '') + '</div></div></div>' +
      '<div class="bd"><p>' + E(a.about) + '</p></div><div class="ft"><span class="pill" style="margin:0">' + E(a.price_text ? (/[₽р]/i.test(a.price_text) ? a.price_text : a.price_text + ' ₽') : 'по договорённости') + '</span>' + proActions(a) + '</div></div>';
  }
  PA.postCard = postCard;

  PA.like = function (id, btn, cat) {
    if (!needLogin(function () { PA.like(id, btn, cat); }, 'Войдите, чтобы ставить лайки')) return;
    api('POST', '/api/posts/' + id + '/like', {}).then(function (r) {
      btn.className = 'likeb' + (r.liked ? ' on' : ''); btn.innerHTML = (r.liked ? '♥' : '♡') + ' <span>' + r.likes + '</span>';
      if (r.liked) bump(cat, 2);
    }).catch(errToast);
  };
  PA.write = function (proId) {
    if (!needLogin(function () { PA.write(proId); }, 'Войдите, чтобы написать специалисту')) return;
    api('POST', '/api/conversations', { pro_id: proId }).then(function (r) { PA.openConv(r.id); var p = (window.PROS || []).filter(function (x) { return x.uid === proId; })[0]; if (p) bump(p.c, 3); }).catch(errToast);
  };

  // ---------- Лента ----------
  var F = { mode: 'foryou', cat: '', q: '', city: '', seed: String(Math.floor(Math.random() * 1e9)), items: [], next: null, busy: false, seen: '', timer: null };
  function seenList() { return lsGet('seen', []); }
  function feedShell() {
    var opts = '<option value="">Все направления</option>' + (window.CATS || []).map(function (c, i) { return '<option value="' + i + '">' + E(c) + '</option>'; }).join('');
    el('cat').innerHTML = '<section><div class="w" style="max-width:760px"><h2>Лента <span class="gt">специалистов</span></h2><p class="tag">Лента подстраивается под вас: чем больше вы смотрите, лайкаете и пишете специалистам, тем точнее рекомендации.</p>' +
      '<div class="srv-tabs" id="ftabs"></div><div class="f2"><input id="qs" placeholder="Поиск: торт, логотип, ремонт…" oninput="PA.feedSoon()"><select id="qc" onchange="PA.feedCat()">' + opts + '</select></div>' +
      '<div class="f2" style="margin-top:8px"><input id="qcity" list="cities" placeholder="Ваш город (для рекомендаций)" onchange="PA.feedCity()"><span class="srvnote" style="align-self:center">Показываем реальные профили и пример-профили — они подписаны.</span></div>' +
      '<div id="onb"></div><div id="cl2" style="max-width:none;margin-top:14px"></div><div class="row" style="justify-content:center"><button class="btn o" id="fmore" style="display:none" onclick="PA.feedMore()">Показать ещё</button></div></div></section>';
    el('qs').value = F.q; el('qc').value = F.cat; el('qcity').value = F.city;
    drawTabs();
  }
  function drawTabs() {
    var t = [['foryou', '✨ Для вас'], ['new', '🆕 Новое'], ['following', '❤ Подписки']];
    el('ftabs').innerHTML = t.map(function (x) { return '<button class="chp' + (F.mode === x[0] ? ' sel' : '') + '" onclick="PA.feedMode(\'' + x[0] + '\')">' + x[1] + '</button>'; }).join('') + '<button class="chp" onclick="PA.feedRefresh()" title="Подобрать заново">🔄 Обновить подборку</button>';
  }
  PA.feedMode = function (m) {
    if (m === 'following' && !needLogin(function () { PA.feedMode(m); }, 'Войдите, чтобы видеть публикации тех, на кого подписаны')) return;
    F.mode = m; drawTabs(); loadFeed(true);
  };
  PA.feedRefresh = function () { F.seed = String(Math.floor(Math.random() * 1e9)); loadFeed(true); };
  PA.feedSoon = function () { clearTimeout(F.timer); F.timer = setTimeout(function () { F.q = el('qs').value.trim(); loadFeed(true); }, 350); };
  PA.feedCat = function () { F.cat = el('qc').value; if (F.cat !== '') bump(+F.cat, 1); loadFeed(true); };
  PA.feedCity = function () { F.city = el('qcity').value.trim(); lsSet('city', F.city); loadFeed(true); };
  PA.feedMore = function () { loadFeed(false); };
  function drawOnb() {
    var box = el('onb'); if (!box) return;
    var has = Object.keys(localInt()).length || (S.me && S.me.interests && Object.keys(S.me.interests).length);
    if (has || lsGet('onbdone', false)) { box.innerHTML = ''; return; }
    box.innerHTML = '<div class="onb"><h3>Что вам интересно?</h3><p class="tag" style="margin:0 0 8px">Отметьте направления — и лента сразу подстроится под вас. Дальше она учится на ваших действиях.</p><div class="chr" style="margin-top:0">' +
      (window.CATS || []).map(function (c, i) { return '<button class="chp" data-c="' + i + '" onclick="this.classList.toggle(\'sel\')">' + E(c) + '</button>'; }).join('') + '</div><div class="row"><button class="btn s" onclick="PA.onbDone(true)">Подобрать ленту</button><button class="btn o s" onclick="PA.onbDone(false)">Пропустить</button></div></div>';
  }
  PA.onbDone = function (apply) {
    if (apply) { var sel = [].slice.call(document.querySelectorAll('#onb .chp.sel')); if (!sel.length) { say('Отметьте хотя бы одно направление'); return; } sel.forEach(function (b) { bump(+b.getAttribute('data-c'), 6); }); }
    lsSet('onbdone', true); drawOnb(); if (apply) loadFeed(true);
  };
  function renderFeed() {
    var box = el('cl2'); if (!box) return;
    if (!F.items.length) { box.innerHTML = '<div class="card"><p class="tag" style="margin:0">' + (F.mode === 'following' ? 'Пока здесь пусто: подпишитесь на специалистов, и их публикации появятся здесь.' : 'Ничего не найдено. Измените запрос или направление.') + '</p></div>'; }
    else box.innerHTML = F.items.map(function (it) { return it.type === 'pro' ? sugCard(it) : postCard(it); }).join('');
    el('fmore').style.display = F.next != null ? '' : 'none';
  }
  function loadFeed(reset) {
    if (F.busy) return; if (!el('cl2')) feedShell();
    F.busy = true;
    if (reset) { F.next = 0; F.seen = seenList().slice(-120).join(','); el('cl2').innerHTML = '<div class="card"><p class="tag" style="margin:0">Подбираем ленту…</p></div>'; }
    var p = ['mode=' + F.mode, 'seed=' + F.seed, 'offset=' + (reset ? 0 : F.next), 'limit=12', 'int=' + encodeURIComponent(intParam()), 'seen=' + F.seen];
    if (F.cat !== '') p.push('cat=' + F.cat); if (F.q) p.push('q=' + encodeURIComponent(F.q)); if (F.city) p.push('city=' + encodeURIComponent(F.city));
    api('GET', '/api/feed?' + p.join('&')).then(function (r) {
      var have = {}; if (!reset) F.items.forEach(function (i) { have[i.type + i.id + (i.author ? i.author.id : '')] = 1; });
      var add = r.items.filter(function (i) { return !have[i.type + i.id + (i.author ? i.author.id : '')]; });
      F.items = reset ? add : F.items.concat(add); F.next = r.next;
      var seen = seenList(); add.forEach(function (i) { if (i.type === 'post') seen.push(i.id); }); lsSet('seen', seen.slice(-300));
      renderFeed();
    }).catch(function (e) { el('cl2').innerHTML = '<div class="card"><p class="tag" style="margin:0">Не удалось загрузить ленту: ' + E(e.message) + '</p></div>'; })
      .finally(function () { F.busy = false; });
  }
  OV.rc2 = function () { showFeed(); };
  function showFeed() {
    if (!F.city) F.city = lsGet('city', '') || (S.me && S.me.profile ? (S.me.profile.city !== 'Удалённо' ? S.me.profile.city : '') : '');
    feedShell(); drawOnb(); loadFeed(true);
  }
  OV.goCat = function (i) { F.cat = String(i); F.mode = 'foryou'; bump(i, 1); window.go('cat'); };

  // ---------- Профиль ----------
  var PRO = { id: null, data: null, imgs: [] };
  PA.openPro = function (id) {
    PRO.id = id; PRO.imgs = []; window.go('prof'); el('pv').innerHTML = '<p class="tag">Загрузка профиля…</p>';
    api('GET', '/api/pros/' + id).then(function (r) { PRO.data = r; drawPro(); bump(r.pro.cat, 1); }).catch(function (e) { el('pv').innerHTML = '<p class="tag">' + E(e.message) + '</p>'; });
  };
  OV.prof = function (i) { var p = (window.PROS || [])[i]; if (p && p.uid) PA.openPro(p.uid); };
  OV.chat = function (name) { var p = (window.PROS || []).filter(function (x) { return x.n === name; })[0]; if (p && p.uid) PA.write(p.uid); };
  function drawPro() {
    var r = PRO.data, p = r.pro, own = r.own, st = r.stats, me = S.me;
    var h = '';
    if (p.demo) h += '<div class="tipsb" style="margin-top:0">ℹ️ Это <b>пример-профиль</b> для демонстрации платформы. Он отвечает как консультант, но реальных заказов у примеров нет.</div>';
    h += '<div class="phead">' + avFromPro(p, true) + '<div class="info"><h2>' + E(p.name) + '</h2><div>' + badges(p) + '</div><div class="tag">' + (p.nick ? '@' + E(p.nick) + ' · ' : '') + E(CATN(p.cat)) + ' · ' + E(p.city) + '</div></div></div>';
    h += '<div class="kpi"><div><b>' + (p.rating ? '★ ' + p.rating : '—') + '</b>рейтинг' + (p.reviews_n ? ' (' + p.reviews_n + ')' : '') + '</div><div><b>' + st.posts + '</b>публикаций</div><div><b>' + st.followers + '</b>подписчиков</div><div><b>' + st.done + '</b>завершённых заказов</div></div>';
    h += '<p>' + E(p.about) + '</p>';
    if (p.services) h += '<p class="tag"><b>Услуги:</b> ' + E(p.services) + '</p>';
    if (p.education) h += '<p class="tag"><b>Образование и опыт:</b> ' + E(p.education) + '</p>';
    if (p.experience) h += '<p class="tag">' + E(p.experience) + '</p>';
    h += '<p><span class="pill">' + E(p.price_text ? (/[₽р]/i.test(p.price_text) ? p.price_text : p.price_text + ' ₽') : 'по договорённости') + '</span>' + '</p>';
    if (own) {
      h += '<div class="row"><button class="btn o s" onclick="PA.editPro()">Изменить профиль</button><button class="btn o s" onclick="go(\'sub\')">Продвижение</button><button class="btn o s" onclick="go(\'inbox\')">Заявки для вас</button></div>';
      var tips = (me && me.tips) || []; if (tips.length) h += '<div class="tipsb"><b>Как получить больше клиентов</b><ul style="margin:6px 0 0;padding-left:18px">' + tips.map(function (t) { return '<li>' + E(t) + '</li>'; }).join('') + '</ul></div>';
      h += '<div class="comp"><b>Новая публикация в блоге</b><input id="ptitle" placeholder="Заголовок (необязательно)" style="margin-top:8px"><textarea id="ptext" placeholder="Расскажите о работе, покажите результат, поделитесь опытом…"></textarea><div class="row" style="margin-top:8px;align-items:center"><label class="btn o s" style="cursor:pointer;margin:0">📷 Добавить фото<input type="file" accept="image/*" multiple style="display:none" onchange="PA.pickImgs(this)"></label><button class="btn s" id="pubbtn" onclick="PA.publish()">Опубликовать</button></div><div class="thumbs" id="pthumbs"></div><p class="srvnote" style="margin:8px 0 0">Публикации попадают в ленту «Для вас» и «Новое». Чем регулярнее и интереснее, тем выше охват.</p></div>';
    } else {
      h += '<div class="row"><button class="btn s" onclick="PA.write(' + p.id + ')">Написать</button>' + '<button class="btn o s" data-fav="' + p.id + '" onclick="PA.fav(' + p.id + ',this)">' + (r.fav ? '★ В избранном' : '☆ В избранное') + '</button><button class="btn o s" id="folbtn" onclick="PA.follow(' + p.id + ')">' + (r.following ? '✓ Вы подписаны' : '＋ Подписаться') + '</button></div>';
    }
    h += '<div class="srv-tabs" style="margin-top:18px"><button class="chp sel" id="tb1" onclick="PA.proTab(1)">Блог</button><button class="chp" id="tb2" onclick="PA.proTab(2)">Отзывы (' + r.reviews.length + ')</button></div><div id="pblog">' + (r.posts.length ? r.posts.map(function (it) { it.author = p; return postCard(it, { noHead: true, noActions: true, own: own }); }).join('') : '<p class="tag">' + (own ? 'Опубликуйте первый пост — так вас заметят в ленте.' : 'Публикаций пока нет.') + '</p>') + '</div><div id="prev" style="display:none">' +
      (r.reviews.length ? r.reviews.map(function (v) { return '<div class="card" style="margin-bottom:10px"><b>' + E(v.author) + '</b> <span class="stars">' + '★'.repeat(v.stars) + '</span><p style="margin:4px 0 0">' + E(v.text || '') + '</p></div>'; }).join('') : '<p class="tag">Отзывов пока нет. Их можно оставить только после завершённой сделки через платформу.</p>') + '</div>';
    el('pv').innerHTML = h;
  }
  PA.proTab = function (n) { el('pblog').style.display = n === 1 ? '' : 'none'; el('prev').style.display = n === 2 ? '' : 'none'; el('tb1').className = 'chp' + (n === 1 ? ' sel' : ''); el('tb2').className = 'chp' + (n === 2 ? ' sel' : ''); };
  PA.follow = function (id) {
    if (!needLogin(function () { PA.follow(id); }, 'Войдите, чтобы подписаться')) return;
    api('POST', '/api/pros/' + id + '/follow', {}).then(function (r) { el('folbtn').textContent = r.following ? '✓ Вы подписаны' : '＋ Подписаться'; if (r.following) bump(PRO.data.pro.cat, 2); }).catch(errToast);
  };
  PA.pickImgs = function (inp) {
    var files = [].slice.call(inp.files).slice(0, 6 - PRO.imgs.length); inp.value = '';
    Promise.all(files.map(function (f) { return shrinkImg(f, 1280, 0.82); })).then(function (arr) { PRO.imgs = PRO.imgs.concat(arr).slice(0, 6); el('pthumbs').innerHTML = PRO.imgs.map(function (s, i) { return '<img alt="" src="' + s + '" title="Нажмите, чтобы убрать" onclick="PA.dropImg(' + i + ')">'; }).join(''); }).catch(errToast);
  };
  PA.dropImg = function (i) { PRO.imgs.splice(i, 1); el('pthumbs').innerHTML = PRO.imgs.map(function (s, k) { return '<img alt="" src="' + s + '" onclick="PA.dropImg(' + k + ')">'; }).join(''); };
  PA.publish = function () {
    var b = el('pubbtn'), text = el('ptext').value.trim(), title = el('ptitle').value.trim();
    if (!text && !PRO.imgs.length) { say('Напишите текст или добавьте фото'); return; }
    btnBusy(b, true);
    api('POST', '/api/posts', { title: title, text: text, images: PRO.imgs }).then(function () { say('Опубликовано! Пост уже в вашем блоге и в ленте.'); PRO.imgs = []; PA.openPro(PRO.id); }).catch(errToast).finally(function () { btnBusy(b, false); });
  };
  PA.delPost = function (id) { if (!confirm('Удалить публикацию?')) return; api('DELETE', '/api/posts/' + id).then(function () { PA.openPro(PRO.id); }).catch(errToast); };

  // ---------- Диалоги и консультации ----------
  var C = { id: null, last: 0, msgs: [], orders: [], conv: null, assist: null, request: null, paid: false, comm: 0.05, first: true };
  function chatShell() {
    el('cv').innerHTML = '<section><div class="w"><div class="card box"><div style="display:flex;gap:10px;align-items:center;margin-bottom:10px"><button class="btn o s" onclick="go(\'me\')">←</button><div id="chead" style="flex:1;min-width:0"></div></div><div id="creq"></div><div id="cmsg"></div><div id="obar"></div><div id="assist"></div>' +
      '<form class="cf" onsubmit="PA.send();return false"><input id="cin" placeholder="Напишите сообщение…" autocomplete="off" maxlength="2000"><button type="submit">➤</button></form><p class="srvnote" style="margin:8px 0 0">Пока заказ не оплачен, телефоны, почта и ссылки в чате скрываются — так вы защищены гарантией возврата.</p></div></div></section>';
  }
  PA.openConv = function (id) {
    C = { id: id, last: 0, msgs: [], orders: [], conv: null, assist: null, request: null, paid: false, comm: 0.05, first: true };
    window.go('cv'); chatShell(); pollConv(); S.convPoll = setInterval(pollConv, 2500);
  };
  function pollConv() {
    if (!C.id || !el('cmsg')) return;
    var cid = C.id;
    api('GET', '/api/conversations/' + cid + '?after=' + C.last).then(function (r) {
      if (cid !== C.id) return;
      var fresh = r.messages.length; C.msgs = C.msgs.concat(r.messages); C.last = r.last_id || C.last; C.orders = r.orders; C.conv = r.conv; C.assist = r.assist || null; C.request = r.request || C.request; C.paid = r.paid; C.comm = r.commission;
      if (C.first || fresh) drawMsgs(); drawHead(); drawOrder(); drawAssist(); C.first = false;
      if (fresh) loadMe();
    }).catch(function (e) { if (e.status === 401 || e.status === 404) { clearInterval(S.convPoll); say(e.message); } });
  }
  function drawHead() {
    var c = C.conv, p = c.peer.pro;
    el('chead').innerHTML = '<div style="display:flex;gap:10px;align-items:center">' + (p ? avFromPro(p) : window.avt({ n: c.peer.name })) + '<div style="min-width:0"><b>' + E(c.peer.name) + '</b>' + (p ? badges(p) : '') + '<div class="tag">' + (p ? E(CATN(p.cat)) + ' · ' + E(p.city) : 'Клиент') + '</div></div></div>';
    var rq = el('creq');
    rq.innerHTML = C.request ? '<div class="tipsb" style="margin-top:0">📝 Заявка клиента: ' + E(C.request.text) + (C.request.budget ? ' · бюджет до ' + money(C.request.budget) : '') + (C.request.city ? ' · ' + E(C.request.city) : '') + '</div>' : '';
  }
  function drawMsgs() {
    var box = el('cmsg'), near = box.scrollHeight - box.scrollTop - box.clientHeight < 80 || C.first;
    box.innerHTML = C.msgs.map(function (m) { return '<div class="m ' + (m.system ? 'b sys' : m.mine ? 'u' : 'b') + '">' + E(m.text) + '</div>'; }).join('') || '<p class="tag" style="margin:auto">Напишите первое сообщение: что нужно сделать, к какому сроку и на какой бюджет.</p>';
    if (near) box.scrollTop = 1e9;
  }
  var ST_RU = { inv: 'Ждёт оплаты', held: 'Оплачен, деньги у платформы', deliv: 'Результат передан', done: 'Завершён', disp: 'Спор' };
  function drawOrder() {
    var role = C.conv.role, o = C.orders[0], p = C.conv.peer.pro, h = '';
    if (!o || o.status === 'done' && role === 'pro' && false) o = o || null;
    if (!o) {
      if (role === 'pro') h = '<div class="ord"><b>Выставить счёт</b><div class="f2" style="margin-top:8px"><input id="invt" placeholder="За что (например: торт 3 кг)" maxlength="120"><input id="inva" type="number" min="100" step="100" placeholder="Сумма, ₽"></div><div class="row"><button class="btn s" onclick="PA.invoice()">Выставить счёт</button></div><p class="srvnote" style="margin:8px 0 0">Клиент оплатит через СБП, деньги будут храниться у платформы до подтверждения результата. Комиссия платформы — ' + Math.round(C.comm * 100) + '%.</p></div>';
      else h = '<div class="ord"><b>🛡 Безопасная сделка</b><p class="srvnote" style="margin:4px 0 0">Договоритесь о задаче в чате — специалист выставит счёт. Деньги хранятся у платформы, пока вы не подтвердите результат.</p>' + (p && p.consult_price ? '<div class="row"><button class="btn y s" onclick="PA.consult(' + p.id + ')">Записаться на консультацию · ' + money(p.consult_price) + '</button></div>' : '') + '</div>';
      el('obar').innerHTML = h; return;
    }
    h = '<div class="ord"><b>' + (o.kind === 'consult' ? '💬 ' : '🧾 ') + E(o.title) + ' — ' + money(o.amount) + '</b> <span class="pill">' + ST_RU[o.status] + '</span>';
    var dispute = '<button class="btn o s" onclick="PA.dispute(' + o.id + ')">Открыть спор</button>';
    if (o.status === 'inv') h += role === 'client' ? '<div class="row"><button class="btn y s" onclick="PA.pay(' + o.id + ')">Оплатить ' + money(o.amount) + ' (СБП)</button></div>' : '<p class="srvnote" style="margin:6px 0 0">Ждём оплату клиента…</p>';
    else if (o.status === 'held') h += role === 'pro' ? '<div class="row"><button class="btn s" onclick="PA.deliver(' + o.id + ')">' + (o.kind === 'consult' ? 'Консультация проведена' : 'Работа выполнена, передать клиенту') + '</button></div>' : '<p class="srvnote" style="margin:6px 0 0">🔒 Деньги у платформы. Специалист выполняет заказ…</p><div class="row">' + dispute + '</div>';
    else if (o.status === 'deliv') h += role === 'client' ? '<div class="row"><button class="btn s" onclick="PA.confirm(' + o.id + ')">Подтвердить получение</button>' + dispute + '</div>' : '<p class="srvnote" style="margin:6px 0 0">Ждём подтверждения клиента…</p>';
    else if (o.status === 'disp') h += '<p class="srvnote" style="margin:6px 0 0">⚠️ Спор на рассмотрении поддержки. Деньги заморожены.</p>';
    else if (o.status === 'done') {
      if (role === 'client' && !o.stars) h += '<div class="row" style="align-items:center"><select id="rvs" style="width:84px"><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select><input id="rvt" placeholder="Ваш отзыв" style="flex:1;min-width:140px"><button class="btn s" onclick="PA.review(' + o.id + ')">Оставить отзыв</button></div>';
      else if (role === 'pro') h += '<p class="srvnote" style="margin:6px 0 0">Заказ завершён. Сумма к выплате — в личном кабинете.</p><div class="row"><button class="btn o s" onclick="PA.newOrder()">Выставить новый счёт</button></div>';
      else h += '<p class="srvnote" style="margin:6px 0 0">Спасибо за отзыв!</p>';
    }
    el('obar').innerHTML = h + '</div>';
  }
  PA.newOrder = function () { C.orders = []; drawOrder(); };
  function drawAssist() {
    var a = C.assist, box = el('assist'); if (!a || C.conv.role !== 'pro') { box.innerHTML = ''; return; }
    var h = '<div class="assist"><h4>💡 Консультант: подсказки по этой заявке</h4>';
    if (a.topic) h += '<div><b>Тема:</b> ' + E(a.topic.name) + ' · по срокам: ' + E(a.topic.time) + '</div>';
    var br = []; if (a.brief.budget) br.push('бюджет ' + money(a.brief.budget)); if (a.brief.deadline) br.push('срок: ' + a.brief.deadline); if (a.brief.qty) br.push('объём: ' + a.brief.qty.n + ' ' + ({ m2: 'м²', guest: 'гостей', kg: 'кг', piece: 'шт.', chars: 'знаков', page: 'стр.', hour: 'ч', lesson: 'занятий' }[a.brief.qty.unit] || ''));
    if (br.length) h += '<div class="tag">Из переписки: ' + E(br.join(' · ')) + '</div>';
    if (a.estimate) h += '<div style="margin-top:6px"><b>Ориентир стоимости:</b> ' + (a.estimate.needQty ? E(a.estimate.basis) : money(a.estimate.lo) + '–' + money(a.estimate.hi) + ' <span class="tag">(' + E(a.estimate.basis) + ')</span>') + (a.estimate.needQty ? '' : ' <button class="chp" style="padding:4px 10px;font-size:12.5px" onclick="PA.fillInvoice(' + a.estimate.mid + ',\'' + E(a.topic ? a.topic.name : 'Услуга').replace(/'/g, '') + '\')">Выставить на ' + money(a.estimate.mid) + '</button>') + '</div>';
    if (a.topic) h += '<div class="tag" style="margin-top:6px">💬 Совет клиенту: ' + E(a.topic.tip) + '</div>';
    if (a.questions.length) h += '<div style="margin-top:8px"><b>Что уточнить у клиента:</b><div class="qs">' + a.questions.map(function (q) { return '<button class="q" onclick="PA.ins(this)">' + E(q) + '</button>'; }).join('') + '</div></div>';
    if (a.drafts.length) h += '<div style="margin-top:8px"><b>Черновики ответа:</b><div class="qs">' + a.drafts.map(function (q) { return '<button class="q" onclick="PA.ins(this)">' + E(q) + '</button>'; }).join('') + '</div></div>';
    h += '<p class="srvnote" style="margin:8px 0 0">Подсказки строятся по переписке и ориентирам рынка, это не оферта. Решение и цена — ваши.</p></div>';
    box.innerHTML = h;
  }
  PA.ins = function (b) { el('cin').value = b.textContent; el('cin').focus(); };
  PA.fillInvoice = function (amount, title) {
    if (C.orders[0] && C.orders[0].status !== 'done') { say('Сначала завершите текущий заказ'); return; }
    if (!el('invt')) { C.orders = []; drawOrder(); }
    el('invt').value = title; el('inva').value = amount; el('inva').scrollIntoView({ behavior: 'smooth', block: 'center' });
  };
  PA.send = function () {
    var i = el('cin'), t = i.value.trim(); if (!t) return; i.value = '';
    api('POST', '/api/conversations/' + C.id + '/messages', { text: t }).then(function (r) { if (r.masked) say('Контакты скрыты до оплаты — общайтесь здесь, в чате'); pollConv(); }).catch(function (e) { i.value = t; errToast(e); });
  };
  PA.invoice = function () {
    var t = el('invt').value.trim(), a = +el('inva').value;
    api('POST', '/api/conversations/' + C.id + '/invoice', { title: t, amount: a }).then(function () { pollConv(); }).catch(errToast);
  };
  PA.pay = function (oid) {
    api('POST', '/api/orders/' + oid + '/pay', {}).then(function (r) { location.href = r.url; }).catch(errToast);
  };
  PA.deliver = function (oid) { api('POST', '/api/orders/' + oid + '/deliver', {}).then(pollConv).catch(errToast); };
  PA.confirm = function (oid) { if (!confirm('Подтвердить, что вы получили результат? Деньги будут переведены специалисту.')) return; api('POST', '/api/orders/' + oid + '/confirm', {}).then(pollConv).catch(errToast); };
  PA.dispute = function (oid) { var r = prompt('Опишите проблему с заказом'); if (!r) return; api('POST', '/api/orders/' + oid + '/dispute', { reason: r }).then(pollConv).catch(errToast); };
  PA.review = function (oid) { api('POST', '/api/orders/' + oid + '/review', { stars: +el('rvs').value, text: el('rvt').value.trim() }).then(function () { say('Спасибо за отзыв!'); pollConv(); }).catch(errToast); };

  // ---------- Личный кабинет ----------
  function meShell() {
    el('me').innerHTML = '<section><div class="w" style="max-width:900px"><h2 style="margin-bottom:16px"><span class="gt">Личный кабинет</span></h2><div id="mehead"></div>' +
      '<div class="srv-tabs" style="margin:16px 0 6px"><button class="chp sel" id="metb_ov" onclick="PA.meTab(\'ov\')">Обзор</button><button class="chp" id="metb_fav" onclick="PA.meTab(\'fav\')">⭐ Избранное</button><button class="chp" id="metb_ord" onclick="PA.meTab(\'ord\')">🧾 История заказов</button></div>' +
      '<div id="metab_ov"><div id="meact" class="grid"></div><div id="metips"></div><div class="two" style="align-items:start;margin-top:18px"><div class="card"><h3>Мои диалоги</h3><div id="mechats" class="lst"><p class="tag">Загрузка…</p></div></div><div class="card"><h3>Мои заявки</h3><div id="mereqs"><p class="tag">Загрузка…</p></div></div></div></div>' +
      '<div id="metab_fav" style="display:none"></div><div id="metab_ord" style="display:none"></div></div></section>';
  }
  function dmy(ts) { return ts ? new Date(ts).toLocaleDateString('ru-RU') : ''; }
  PA.meTab = function (t) {
    ['ov', 'fav', 'ord'].forEach(function (k) { var b = el('metb_' + k), c = el('metab_' + k); if (b) b.className = 'chp' + (k === t ? ' sel' : ''); if (c) c.style.display = k === t ? '' : 'none'; });
    if (t === 'fav') loadFavs(); if (t === 'ord') loadOrders();
  };
  function loadFavs() {
    var box = el('metab_fav'); box.innerHTML = '<p class="tag">Загрузка…</p>';
    api('GET', '/api/favs').then(function (r) {
      if (!r.pros.length) { box.innerHTML = '<div class="card"><p class="tag" style="margin:0">В избранном пока пусто. Нажмите «☆ В избранное» у публикации или в профиле специалиста, чтобы вернуться к нему позже.</p><div class="row" style="margin-top:10px"><button class="btn s" onclick="go(\'cat\')">Открыть ленту</button></div></div>'; return; }
      box.innerHTML = '<div class="grid">' + r.pros.map(function (a) {
        return '<div class="card" id="favc' + a.id + '"><div style="display:flex;gap:12px;align-items:center;cursor:pointer" onclick="PA.openPro(' + a.id + ')">' + avFromPro(a) + '<div><b>' + E(a.name) + '</b>' + (a.demo ? ' <span class="pill" style="margin:0">Пример</span>' : '') + '<div class="tag">' + E(CATN(a.cat)) + ' · ' + E(a.city) + '</div></div></div>' +
          '<p class="tag" style="margin:10px 0 0">' + E((a.about || '').slice(0, 110)) + '</p><p><span class="pill">' + E(a.price_text ? (/[₽р]/i.test(a.price_text) ? a.price_text : a.price_text + ' ₽') : 'по договорённости') + '</span></p>' +
          '<div class="row"><button class="btn s" onclick="PA.openPro(' + a.id + ')">Профиль</button><button class="btn o s" onclick="PA.write(' + a.id + ')">Написать</button><button class="btn o s" onclick="PA.unfav(' + a.id + ')">Убрать</button></div></div>';
      }).join('') + '</div>';
    }).catch(function (e) { box.innerHTML = ''; errToast(e); });
  }
  PA.unfav = function (id) { api('POST', '/api/pros/' + id + '/fav', {}).then(function (r) { if (!r.fav) loadFavs(); }).catch(errToast); };
  function loadOrders() {
    var box = el('metab_ord'); box.innerHTML = '<p class="tag">Загрузка…</p>';
    api('GET', '/api/orders/mine').then(function (r) {
      var os = r.orders;
      if (!os.length) { box.innerHTML = '<div class="card"><p class="tag" style="margin:0">Заказов пока нет. Договоритесь о задаче в чате со специалистом — после выставления счёта заказ появится здесь.</p></div>'; return; }
      var done = os.filter(function (o) { return o.status === 'done'; }), sumC = 0, sumP = 0;
      done.forEach(function (o) { if (o.role === 'client') sumC += o.amount; else sumP += o.amount; });
      var h = '<div class="card" style="margin-bottom:12px"><b>Всего заказов: ' + os.length + '</b> · завершено: ' + done.length + (sumC ? ' · потрачено: ' + money(sumC) : '') + (sumP ? ' · заработано (до комиссии): ' + money(sumP) : '') + '</div><div class="lst">';
      h += os.map(function (o) {
        var peer = o.peer && o.peer.name ? o.peer.name : '—';
        return '<div class="it" onclick="PA.openConv(' + o.conv_id + ')"><div class="tx"><b>' + E(o.title || 'Заказ') + '</b> <span class="pill">' + (ST_RU[o.status] || o.status) + '</span>' +
          '<p>' + money(o.amount) + ' · ' + (o.role === 'client' ? 'специалист: ' : 'клиент: ') + E(peer) + ' · ' + dmy(o.created) + (o.stars ? ' · отзыв: ' + '★'.repeat(o.stars) : '') + '</p></div></div>';
      }).join('') + '</div>';
      box.innerHTML = h;
    }).catch(function (e) { box.innerHTML = ''; errToast(e); });
  }
  PA.fav = function (id, btn) {
    if (!needLogin(function () { PA.fav(id, btn); }, 'Войдите, чтобы добавить в избранное')) return;
    api('POST', '/api/pros/' + id + '/fav', {}).then(function (r) {
      document.querySelectorAll('[data-fav="' + id + '"]').forEach(function (b) { b.textContent = r.fav ? '★ В избранном' : '☆ В избранное'; });
      say(r.fav ? 'Добавлено в избранное' : 'Убрано из избранного');
    }).catch(errToast);
  };
  function renderMe() {
    if (!S.me) { window._after = function () { window.go('me'); }; return window.authOpen(); }
    meShell(); var m = S.me, p = m.profile;
    el('mehead').innerHTML = '<div class="card" style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">' + (p ? avFromPro(p, true) : window.avt({ n: m.user.name }, true)) + '<div style="flex:1;min-width:180px"><h3 style="font-size:22px;margin:0">' + E(m.user.name) + '</h3><div class="tag">' + E(m.user.email) + ' · устройство запомнено</div><div style="margin-top:8px"><span class="pill">Клиент</span>' + (p ? '<span class="pill" style="background:#fff3c4;color:#8a6500">Специалист' + (p.verified ? ' · проверен' : ' · на проверке') + '</span>' : '') + (m.sub ? '<span class="pill" style="background:#e3edff">★ продвижение до ' + new Date(m.sub.until).toLocaleDateString('ru-RU') + '</span>' : '') + '</div></div><button class="btn o s" onclick="logout()">Выйти</button></div>';
    var act = '<div class="card"><div class="ic">🔎</div><h3>Я ищу специалиста</h3><p>Опишите задачу — специалисты откликнутся.</p><div class="row"><button class="btn s" onclick="go(\'cl\')">Опишите задачу</button></div></div>' +
      '<div class="card"><div class="ic">🧑‍💼</div><h3>' + (p ? 'Мой профиль и блог' : 'Стать специалистом') + '</h3><p>' + (p ? 'Публикуйте работы, ведите блог, попадайте в ленту.' : 'Создайте профиль, ведите блог и получайте клиентов.') + '</p><div class="row">' + (p ? '<button class="btn y s" onclick="PA.openPro(' + p.id + ')">Открыть</button><button class="btn o s" onclick="go(\'pro\')">Изменить</button>' : '<button class="btn y s" onclick="go(\'pro\')">Создать профиль</button>') + '</div></div>';
    if (p) act += '<div class="card"><div class="ic">📥</div><h3>Заявки для вас' + (m.inbox ? '<span class="unr">' + m.inbox + '</span>' : '') + '</h3><p>Клиенты, которым нужна ваша помощь.</p><div class="row"><button class="btn s" onclick="go(\'inbox\')">Открыть</button></div></div>' +
      '<div class="card"><div class="ic">💰</div><h3>К выплате: ' + money(m.balance) + '</h3><p>Комиссия платформы ' + Math.round(((S.health && S.health.commission) || 0.05) * 100) + '% уже удержана. ' + (S.health && S.health.payments === 'test' ? 'Сейчас включён тестовый режим: реальные выплаты подключаются вместе с платёжным провайдером.' : '') + '</p><div class="row"><button class="btn o s" onclick="go(\'sub\')">Продвижение</button></div></div>';
    el('meact').innerHTML = act;
    el('metips').innerHTML = p && m.tips && m.tips.length ? '<div class="tipsb"><b>Как получить больше клиентов</b><ul style="margin:6px 0 0;padding-left:18px">' + m.tips.map(function (t) { return '<li>' + E(t) + '</li>'; }).join('') + '</ul></div>' : '';
    Promise.all([api('GET', '/api/conversations'), api('GET', '/api/requests/mine')]).then(function (rs) {
      var cs = rs[0].conversations, rq = rs[1].requests;
      el('mechats').innerHTML = cs.length ? cs.map(function (c) {
        var p2 = c.peer.pro; var last = c.last ? c.last.text : '';
        return '<div class="it" onclick="PA.openConv(' + c.id + ')">' + (p2 ? avFromPro(p2) : window.avt({ n: c.peer.name })) + '<div class="tx"><b>' + E(c.peer.name) + '</b>' + (c.unread ? '<span class="unr">' + c.unread + '</span>' : '') + (c.order ? ' <span class="pill">' + ST_RU[c.order.status] + '</span>' : '') + '<p>' + E(last) + '</p></div></div>';
      }).join('') : '<p class="tag">Диалогов пока нет. Найдите специалиста в ленте и напишите ему.</p>';
      el('mereqs').innerHTML = rq.length ? rq.map(function (r) { return '<div class="it" onclick="go(\'cl\')"><div class="tx"><b>' + E(CATN(r.cat)) + '</b> <span class="pill">' + r.responses.length + ' откликов</span><p>' + E(r.text) + '</p></div></div>'; }).join('') : '<p class="tag">Заявок нет. Опишите задачу — специалисты откликнутся.</p>';
    }).catch(errToast);
  }

  // ---------- Заявки клиента ----------
  var REQP = null;
  function showCl() {
    if (!S.me) { window._after = function () { window.go('cl'); }; return window.authOpen(); }
    if (!el('qcity_cl') && el('rcity')) { /* форма уже есть */ }
    drawReqs(); REQP = setInterval(drawReqs, 6000);
  }
  function drawReqs() {
    var out = el('out'); if (!out) return;
    api('GET', '/api/requests/mine').then(function (r) {
      if (!r.requests.length) { out.innerHTML = '<p style="color:var(--mu);margin:0">Здесь появятся ваши заявки и отклики специалистов.</p>'; return; }
      out.innerHTML = '<h3 style="margin-top:0">Ваши заявки и отклики</h3>' + r.requests.map(function (q) {
        return '<div class="rq"><p><b>' + E(CATN(q.cat)) + '</b> · ' + ago(q.created) + (q.budget ? ' · до ' + money(q.budget) : '') + (q.city ? ' · ' + E(q.city) : '') + '</p><p>' + E(q.text) + '</p>' +
          (q.responses.length ? q.responses.map(function (s) { return '<div class="rsp" onclick="PA.openConv(' + s.conv_id + ')">' + window.avt({ n: s.name, av: s.avatar, demo: s.demo }) + '<div style="flex:1;min-width:0"><b>' + E(s.name) + '</b>' + badges({ demo: s.demo }) + (s.rating ? ' <span class="stars">★ ' + s.rating + '</span>' : '') + '<div class="tag" style="white-space:normal">' + E((s.first || '').slice(0, 220)) + '</div></div></div>'; }).join('') : '<p class="tag" style="margin:0">Откликов пока нет — специалисты вашего направления увидят заявку и напишут вам.</p>') + '</div>';
      }).join('');
    }).catch(function () {});
  }
  OV.sendReq = function () {
    var text = el('rq').value.trim(), cat = el('rc').value, bud = +el('rb').value || 0, city = el('rcity').value.trim();
    if (cat === '') cat = String((window.guessC ? window.guessC(text) : 0));
    api('POST', '/api/requests', { text: text, cat: +cat, budget: bud, city: city }).then(function () { el('rq').value = ''; say('Заявка отправлена. Отклики появятся справа.'); bump(+cat, 4); drawReqs(); }).catch(errToast);
  };

  // ---------- Входящие заявки специалиста ----------
  function drawInbox() {
    if (!S.me) { window._after = function () { window.go('inbox'); }; return window.authOpen(); }
    if (!S.me.profile) { say('Сначала создайте профиль специалиста'); return window.go('pro'); }
    var box = el('il'); box.innerHTML = '<p class="tag">Загрузка…</p>';
    api('GET', '/api/requests/inbox').then(function (r) {
      box.innerHTML = r.requests.length ? r.requests.map(function (q) {
        var hint = q.hint ? '<div class="tag">💡 ' + E(q.hint.topic || '') + (q.hint.lo ? ' · ориентир ' + money(q.hint.lo) + '–' + money(q.hint.hi) : '') + '</div>' : '';
        var act = q.responded ? '<div class="row"><button class="btn o s" onclick="PA.openConv(' + q.responded + ')">Открыть диалог</button></div>' :
          '<div id="rsp' + q.id + '"><div class="row"><button class="btn s" onclick="PA.respOpen(' + q.id + ')">Откликнуться</button></div></div>';
        return '<div class="rq" data-q=\'' + E(JSON.stringify({ t: q.hint ? q.hint.topic : '', lo: q.hint && q.hint.lo, hi: q.hint && q.hint.hi, b: q.budget })) + '\'><p><b>' + E(q.client) + '</b> · ' + ago(q.created) + (q.budget ? ' · до ' + money(q.budget) : '') + (q.city ? ' · ' + E(q.city) : '') + (q.local ? '' : ' <span class="pill">другой город</span>') + '</p><p>' + E(q.text) + '</p>' + hint + act + '</div>';
      }).join('') : '<p class="tag">Пока заявок нет. Как только клиент опубликует подходящую задачу, она появится здесь.</p>';
    }).catch(errToast);
  }
  PA.respOpen = function (id) {
    var card = el('rsp' + id).closest('.rq'), d = {}; try { d = JSON.parse(card.getAttribute('data-q')); } catch (e) { /* ignore */ }
    var draft = 'Здравствуйте! Ваша заявка мне подходит.' + (d.t ? ' Задача: ' + d.t + '.' : '') + (d.lo ? ' Ориентир по стоимости — ' + money(d.lo) + '–' + money(d.hi) + '.' : '') + ' Чтобы предложить точный вариант, подскажите сроки и детали. Готов(а) обсудить в чате.';
    el('rsp' + id).innerHTML = '<textarea id="rt' + id + '" style="min-height:100px">' + E(draft) + '</textarea><div class="row"><button class="btn s" onclick="PA.respSend(' + id + ')">Отправить отклик</button></div><p class="srvnote">Контакты до оплаты не передаются — общайтесь в чате платформы.</p>';
  };
  PA.respSend = function (id) {
    api('POST', '/api/requests/' + id + '/respond', { text: el('rt' + id).value.trim() }).then(function (r) { say('Отклик отправлен'); PA.openConv(r.conv_id); }).catch(errToast);
  };

  // ---------- Форма профиля ----------
  var PF = { av: null };
  function proShell() {
    var cats = (window.CATS || []).map(function (c, i) { return '<option value="' + i + '">' + E(c) + '</option>'; }).join('');
    el('pro').innerHTML = '<section><div class="w"><div class="card box"><h2 id="f_phd">Ваш <span class="gt">профиль</span></h2><p class="tag">Профиль публикуется сразу и попадает в ленту. Публикации блога можно добавлять на странице профиля.</p>' +
      '<div style="display:flex;gap:14px;align-items:center;margin-bottom:6px"><div id="f_avp" class="av big dflt">?</div><div style="flex:1"><label style="margin-top:0">Аватарка или ваше фото</label><input type="file" accept="image/*" onchange="PA.pickAv(this)"></div></div>' +
      '<label>Никнейм</label><input id="f_pnick" placeholder="например, nastya.cakes"><label>ФИО</label><input id="f_pn"><label>Направление</label><select id="f_pcat">' + cats + '</select>' +
      '<label>Мои услуги: что вы продаёте или производите</label><textarea id="f_pc" placeholder="Например: торты на заказ, капкейки, пряники"></textarea><label>Город</label><input id="f_pcity" list="cities" placeholder="Москва или «Удалённо»">' +
      '<label>Образование и опыт</label><input id="f_pe" placeholder="Вуз, курсы, сертификаты, стаж"><label>Выполненные работы (по желанию)</label><textarea id="f_px"></textarea><label>Описание профиля: о себе и услугах</label><textarea id="f_pd"></textarea>' +
      '<label>Стоимость услуг, ₽</label><input id="f_pp" placeholder="например: от 3000 или 3000-8000">' +
      '<h3 style="margin-top:22px">Подтверждение статуса</h3><p class="tag">Продавать услуги могут ИП и самозанятые от 16 лет, которые платят налоги. Для самозанятых мы сверяем ИНН со статусом в ФНС; пока проверка не пройдена, профиль подписан «на проверке». Скан паспорта не нужен.</p>' +
      '<div class="f2"><div><label>ИНН (12 цифр)</label><input id="f_vi" inputmode="numeric" maxlength="12"></div><div><label>Статус</label><select id="f_vs"><option>Самозанятый</option><option>ИП</option></select></div></div>' +
      '<label id="f_vcw" style="display:flex;gap:8px;align-items:flex-start;color:var(--tx)"><input type="checkbox" id="f_vc" style="width:auto;margin-top:4px">Подтверждаю, что мне есть 16 лет, я зарегистрирован как ИП или самозанятый и самостоятельно плачу налоги с доходов</label>' +
      '<div class="row"><button class="btn" id="f_psave" onclick="saveP()">Опубликовать профиль</button></div></div></div></section>';
  }
  function fillProForm() {
    if (!S.me) { window._after = function () { window.go('pro'); }; return window.authOpen(); }
    proShell(); PF.av = null; var p = S.me.profile;
    el('f_pn').value = S.me.user.name;
    if (p) {
      el('f_phd').innerHTML = 'Изменить <span class="gt">профиль</span>'; el('f_psave').textContent = 'Сохранить'; el('f_vcw').style.display = 'none';
      el('f_pnick').value = p.nick || ''; el('f_pn').value = p.name; el('f_pcat').value = p.cat; el('f_pc').value = p.services || ''; el('f_pcity').value = p.city || ''; el('f_pe').value = p.education || ''; el('f_px').value = p.experience || ''; el('f_pd').value = p.about || '';
      el('f_pp').value = p.price_text || ''; el('f_vi').value = p.inn || ''; el('f_vs').value = p.status || 'Самозанятый';
      if (p.avatar) el('f_avp').innerHTML = '<img class="avi" alt="" src="' + E(p.avatar) + '">', el('f_avp').className = 'av big';
    }
  }
  PA.pickAv = function (inp) {
    var f = inp.files[0]; if (!f) return;
    shrinkImg(f, 400, 0.85).then(function (d) { PF.av = d; el('f_avp').innerHTML = '<img class="avi" alt="" src="' + d + '">'; el('f_avp').className = 'av big'; }).catch(errToast);
  };
  OV.saveP = function () {
    var b = el('f_psave');
    var body = { nick: el('f_pnick').value.trim(), name: el('f_pn').value.trim(), cat: +el('f_pcat').value, services: el('f_pc').value.trim(), city: el('f_pcity').value.trim(), education: el('f_pe').value.trim(), experience: el('f_px').value.trim(), about: el('f_pd').value.trim(), price_text: el('f_pp').value.trim(), inn: el('f_vi').value.trim(), status: el('f_vs').value, confirmAge: S.me.profile ? true : el('f_vc').checked };
    if (PF.av) body.avatar = PF.av;
    btnBusy(b, true);
    api('PUT', '/api/profile', body).then(function (r) { say(S.me.profile ? 'Профиль сохранён' : 'Профиль опубликован — вас уже видно в ленте!'); return Promise.all([loadMe(), loadPros()]).then(function () { PA.openPro(r.profile.id); }); }).catch(errToast).finally(function () { btnBusy(b, false); });
  };

  // ---------- Подписка ----------
  OV.subBuy = function () {
    if (!needLogin(function () { window.subBuy(); }, 'Войдите, чтобы оформить подписку')) return;
    if (!S.me.profile) { say('Продвижение доступно специалистам: сначала создайте профиль'); return window.go('pro'); }
    api('POST', '/api/subscribe', { months: window.SX.m, price: window.SX.p }).then(function (r) { location.href = r.url; }).catch(errToast);
  };
  function subInfo() {
    if (window.drawSub) window.drawSub();
    var s = S.me && S.me.sub, a = el('sact');
    if (a) a.textContent = s ? 'Продвижение активно до ' + new Date(s.until).toLocaleDateString('ru-RU') + ' (уровень ' + s.level + ' из 3). Новая подписка продлит срок.' : '';
    var notes = document.querySelectorAll('#sub .tag'); var n = notes[notes.length - 1];
    if (n) n.textContent = S.health && S.health.payments === 'test' ? 'Сейчас включён тестовый режим оплаты: откроется страница СБП-оплаты, деньги не списываются.' : 'Оплата проходит через СБП или карту у платёжного провайдера.';
  }

  // ---------- Навигация ----------
  function stopPolls() { clearInterval(S.convPoll); clearInterval(REQP); S.convPoll = null; REQP = null; }
  function onShow(v) {
    if (v === 'cat') showFeed(); else if (v === 'me') renderMe(); else if (v === 'pro') fillProForm(); else if (v === 'cl') showCl(); else if (v === 'inbox') drawInbox(); else if (v === 'sub') subInfo();
  }
  function wrapGo() {
    window.cab = function () {}; // старый демо-кабинет прототипа; новый рисует renderMe()
    var g = window.go;
    window.go = function (v) { stopPolls(); g.apply(null, arguments); onShow(v); };
  }

  // ---------- Запуск ----------
  function boot() {
    api('GET', '/api/health').then(function (h) {
      if (!h || !h.ok) throw new Error('no server'); S.health = h; document.body.classList.add('srv'); for (var k in OV) window[k] = OV[k];
      meShell(); chatShell(); proShell(); wrapGo();
      var q = new URLSearchParams(location.search), pay = q.get('pay'), conv = q.get('conv');
      return Promise.all([loadMe(), loadPros()]).then(function () {
        if (pay) {
          history.replaceState(null, '', location.pathname);
          api('POST', '/api/pay/sync', {}).catch(function () {}).then(loadMe).then(function () {
            if (q.get('canceled')) { say('Оплата отменена'); if (conv) PA.openConv(+conv); return; }
            if (pay === 'sub') { say('Подписка оформлена — продвижение включено'); if (S.me && S.me.profile) PA.openPro(S.me.profile.id); }
            else { say('Оплата прошла. Деньги хранятся у платформы до подтверждения результата.'); if (conv) PA.openConv(+conv); }
          });
        }
      });
    }).then(function () {
      setInterval(function () { if (S.me) loadMe(); }, 20000);
    }).catch(function () { /* сервера нет — остаётся демо-режим */ });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
